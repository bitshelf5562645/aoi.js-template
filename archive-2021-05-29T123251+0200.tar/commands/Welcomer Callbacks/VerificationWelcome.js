module.exports.joinCommand = ({
channel: "789522874129842216",
code: `$title[welcome]
<@$authorid>
$description[Welcome $usertag[$authorid], This is Bittyconomy Official, to verify please follow these steps:
First generate a captcha code by running the command \`\`\`B!gencaptcha\`\`\`
Then pull the captcha code by running the command \`\`\`B!captcha\`\`\`
Now that you can see the captcha code all you have to do is send the exact code you see, including cased letter where needed, after that you're done!
If the bot doesn't react to the code you sent it means you sent the wrong code.
**There is also a message containing how to verify in the pins.**]
$color[f1c40f]
$image[https://cdn.discordapp.com/attachments/760598463984566274/841648648613265408/image0.jpg]
$onlyForservers[775657653602877460;]`
})