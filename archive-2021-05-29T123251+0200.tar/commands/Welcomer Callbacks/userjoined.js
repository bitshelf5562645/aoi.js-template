module.exports.joinCommand = ({
	channel: '$getServerVar[welcome]',
	code: `
  $title[Everyone welcome $usertag[$authorID]]
  $description[$getServerVar[welcomeMessage]

We now have $numberseparator[$memberscount;,] members.]
  $addTimestamp
  $image[$serverIcon]
  $thumbnail[$authoravatar]
  $color[$getServerVar[color]]`
});
