module.exports.leaveCommand = ({
	channel: '$getServerVar[welcome]',
	code: `
  $title[Goodbye $usertag[$authorID]]
  $description[$getServerVar[goodbyeMessage]

We now have $numberseparator[$memberscount;,] members.]
  $addTimestamp
  $image[$serverIcon]
  $thumbnail[$authoravatar]
  $color[$getServerVar[color]]`
});