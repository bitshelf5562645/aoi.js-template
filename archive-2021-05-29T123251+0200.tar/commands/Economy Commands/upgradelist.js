module.exports.command = ({
  name: "upgradelist",
  code: `$title[Upgrades!]
  $description[Available upgrades:
sum bank upgrades:

Small bank upgrade: increases max deposit by 10,000, costs 15,000 BittyCoins.
Medium bank upgrade: increases max deposit by 30,000, costs 40,000 BittyCoins.
Big bank upgrade: increases max deposit by 70,000, costs 90,000 BittyCoins.
Giant bank upgrade: increases max deposit by 150,000, costs 190,000 BittyCoins.
To use a sum upgrade run for example \`$getservervar[prefix]upgradesum small bank upgrade\`
  

Multiplier bank upgrades:

Small bank multiplier: multiplies max deposit by 1,1, costs 40,000 BittyCoins.
Medium bank multiplier: multiplies max deposit by 1,3, costs 80,000 BittyCoins.
Big bank multiplier: multiplies max deposit by 1,5, costs 100,000 BittyCoins.
Giant bank multiplier: mupltiplies max deposit by 
2, costs 200,000 BittyCoins.
To use a multiplier upgrade run for example \`$getservervar[prefix]upgrademulti small bank upgrade\`
  
Keep in mind you need to have money in your wallet to buy and/or upgrade items.]
  $color[$getservervar[color]]
  $footer[requested by $usertag;$authoravatar]`
})