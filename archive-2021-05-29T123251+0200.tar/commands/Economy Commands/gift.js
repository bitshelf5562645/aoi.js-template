module.exports.command = ({
name: "gift",
code: `
$setglobaluservar[hasGiftedSomething;true;$authorid]
$title[TRADING!]
$description[$username[$authorID] gave one $tolowercase[$noMentionMessage] to $username[$mentioned[1;no]]!]
$footer[requested by $username[$authorID]#$discriminator[$authorID];$authoravatar]
$color[$getservervar[color]]
$addTimestamp
$setglobaluservar[$replacetext[$tolowercase[$noMentionMessage]; ;_;-1]_amount;$sum[$getglobaluservar[$replacetext[$tolowercase[$noMentionMessage]; ;_;-1]_amount];-1]]
$setglobaluservar[$replacetext[$tolowercase[$noMentionMessage]; ;_;-1]_amount;$sum[$getglobaluservar[$replacetext[$tolowercase[$noMentionMessage]; ;_;-1]_amount;$mentioned[1;no]];1];$mentioned[1;no]]
$onlyif[$getglobaluservar[$replacetext[$tolowercase[$noMentionMessage]; ;_;-1]_amount]>=1;You can't give someone something you don't have!]
$onlyif[$mentioned[1;no]!=$authorid;You can't give something to yourself!]
$onlyif[$mentioned[1;no]!=;Usage: \`$getservervar[prefix]gift <@mention> <item>\`]
$suppresserrors[Please select a valid item!]
`
})