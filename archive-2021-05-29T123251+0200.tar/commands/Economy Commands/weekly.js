module.exports.command = ({
    name: "weekly",
    description: `This command gives you your weekly money`,
  code: `$title[weekly money!]
$thumbnail[$authorAvatar]
$addField[Claimed!;You succesfully claimed a weeks worth of 30,000 BittyCoins!]
$footer[requested by $usertag[$authorID]]
$addTimestamp
$color[$getServerVar[color]]

$setGlobalUserVar[money;$sum[$getGlobalUserVar[money];30000]]

$globalCooldown[1w; wait for **%time%** to claim your money again]`
})