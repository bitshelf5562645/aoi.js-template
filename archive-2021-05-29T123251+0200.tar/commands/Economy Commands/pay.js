module.exports.command = ({
  name: "pay",
  description: `Pay the mentioned user the mentioned amount of money.`,
  code: `$color[$getServerVar[color]]


$setGlobalUserVar[money;$sum[$getGlobalUserVar[money;$mentioned[1;no]];$message[2]];$mentioned[1;no]]

$setGlobalUserVar[money;$sum[$getGlobalUserVar[money];-$message[2]]]

$title[Transaction complete!]
$description[You paid <@$mentioned[1;no]> $numberSeparator[$message[2];,] BittyCoins.]
$footer[requested by $usertag[$authorID];$authorAvatar]
$addTimestamp

$onlyIf[$checkContains[$message;-]==false;You can’t pay someone negative money!]

$onlyIf[$getGlobalUserVar[money]>=$message[2];You can’t pay someone more than what you have!]

$onlyIf[$isBot[$mentioned[1;no]]==false;You can’t pay a bot! Please mention someone else!]

$onlyIf[$mentioned[1;no]!=$authorID;You can’t pay yourself! Please mention someone else!]

$argsCheck[2;Usage: b!pay user amount]`
});