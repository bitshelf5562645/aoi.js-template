module.exports.command = ({
  name: "withdraw",
  aliases: ["with"],
  code: `$title[Withdrawal successful!]
  $description[You successfully withdrew $message[1] BittyCoins from your bank!]
  $footer[requested by $usertag;$authoravatar]
  $color[$getServerVar[color]]
 $setGlobalUserVar[deposited;$sum[$getGlobalUserVar[deposited];-$message[1]]]
 $setGlobalUserVar[money;$sum[$getGlobalUserVar[money];$message[1]]]
 $onlyif[$getGlobalUserVar[deposited]>=$message[1];You cant withdraw more than you have deposited!]
  $onlyIf[$checkContains[$message;1;2;3;4;5;6;7;8;9;0]==true;]
  $onlyIf[$checkContains[$message[1];q;w;e;r;t;y;u;i;o;p;s;d;f;g;h;j;k;z;x;c;v;b;n;m]==false;Please only send the amount of Bittycoins you want to withdraw!]

  `
})