module.exports.command = ({
  name: "shop",
  description: `This command shows the items that are able to be bought.`,
  code: `$title[Hello there, please do come in!]
  $description[Hello there \`$userTag[$authorID]\`, we don't get visitors very often, please do enjoy your stay.
  ** **
  :fishing_pole_and_fish:, fishing rod, buy this to be able to fish, 15,000 BittyCoins $customemoji[bittycoin].
<:lock:790522469789597706>, lock, use this to protect yourself from one rob attempt, 10,000 BittyCoins $customemoji[bittycoin].
<a:adv_frogGun:795239560296398879>, hunting rifle, buy this to be able to use $getservervar[prefix]hunt 20,000 BittyCoins $customemoji[bittycoin].
<:LotteryTicket:788807601097932801>, a lottery ticket, have a small chance of winning a max of 40,000 BittyCoins, costs 3000 BittyCoins $customemoji[bittycoin].
$customemoji[Bittytrophy], Bittytrophy, 1,000,000 BittyCoins $customemoji[bittycoin], flex item.
<:BittyCoinsole:844477120930381844>, BittyCoinsole, the official Bittycity Certified Console! 7000 BittyCoins $customemoji[bittycoin].

\`experimental items\`
$customemoji[moneycrate], a money crate, you can win some BittyCoins with this by using $getservervar[prefix]moneycrate, 5000 BittyCoins $customemoji[bittycoin].
]
  
  
  $color[$getServerVar[color]]
  $footer[Requested by $userTag[$authorID];$authorAvatar]
  $addTimeStamp`
})