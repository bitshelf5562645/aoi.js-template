module.exports.command = ({
  name: "beg",
  code: `$title[Begging]
$description[You begged $randomText[on the streets;in the city;at a house;at a park] and $randomText[Jeff Bezos;Cool Stickman;John Cena;Some Guy felt bad for you and;an idiot] gave you $numberseparator[$multi[$getGlobalUserVar[prestige_multiplier];$random[500;3000]];,] BittyCoins]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addTimestamp
$setglobaluserVar[money;$sum[$getglobaluservar[money];$multi[$getGlobalUserVar[prestige_multiplier];$random[500;3000]]]]
$globalCooldown[5m;You have to wait for %time% before you can beg again.]
`
})