module.exports.command = ({
  name: "rob",
  code: `$setglobaluservar[lock_equipped;false;$mentioned[1;no]]
  
$globalCooldown[5m;]

$onlyIf[$mentioned[1;no]!=$authorID;]

$onlyIf[$isBot[$mentioned[1;no]]==false;]

$onlyIf[$getglobaluserVar[money;$mentioned[1;no]]>=6000;]

$onlyIf[$getglobaluserVar[lock_equipped;$mentioned[1;no]]==true;]

$suppressErrors`
})