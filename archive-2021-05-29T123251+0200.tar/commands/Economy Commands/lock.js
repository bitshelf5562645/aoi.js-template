module.exports.command = ({
  name: "lock",
description: `This command locks your wallet.`,
  code: `$title[Locked 'n loaded!]
$description[You used a lock, you will now be safe against one rob attempt, this lock will stay equipped until disabled when someone tries to rob you.]
$footer[requested by $username[$authorID]#$discriminator[$authorID];$authoravatar]
$addTimestamp
$color[$getservervar[color]]
$thumbnail[https://cdn.discordapp.com/emojis/790522469789597706.png?size4096]
$setglobaluservar[lock_equipped;true]
$setglobaluservar[lock_amount;$sum[$getglobaluservar[lock_amount];-1]]
$onlyIf[$getglobaluservar[lock_equipped]==false;{title:NO DOUBLE TROUBLE!}{description:You already have a lock equipped, you can't use two at the same time!}{color:$getservervar[color]}]
$onlyIf[$getglobaluservar[lock_amount]>=1;{title:404 Lock not found!}{description:You don't have a lock to use! Please buy one in the shop!}{color:$getservervar[color]}]`
})