module.exports.command = ({
name: "gamestore",
aliases: "gameshop",
code: `$title[Welcome!]
$description[Hi there $usernameForTheWin! Welcome to BittySoft's game store, enjoy your stay!

			**Games currently for sale:**
$addfield[Subnautica: Below Zero;$getglobaluservar[subnautica_cost];yes]
$addfield[Minecraft;$getglobaluservar[minecraft_cost];yes] 
$addfield[Kirby: The disappearance of the BittyCoin;$getglobaluservar[kirby_cost];yes]
$addfield[Friday Night Funkin';$getglobaluservar[friday_cost];yes]
$addfield[Call Of Duty: Coin Ops;$getglobaluservar[call_cost];yes]
$addfield[Plants VS Zombies: Coin Warfare;$getglobaluservar[plants_cost];yes]

$addfield[** **;To buy a game use $getservervar[prefix]purchase <**first word** *of the game's name*>;no]]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$onlyif[$getglobaluservar[bittycoinsole_amount]>=1;You can't access BittySoft's game store without a BittyCoinsole!]`
})