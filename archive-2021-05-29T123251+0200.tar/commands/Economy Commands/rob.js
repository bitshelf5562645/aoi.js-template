module.exports.command = ({
  name: "rob",
  description: `This command allows you to rob the mentoned user of some money, you will only get money if the user doe not have a lock equipped.`,
  code: `
$setglobaluserVar[money;$sum[$getglobaluserVar[money];$random[100;6000]]]

$setglobaluserVar[money;$sum[$getglobaluserVar[money;$mentioned[1;no]];-$random[100;6000]];$mentioned[1;no]]

$title[You dirty dirty thief!]
$description[You stole $random[100;6000] BittyCoins from $username[$mentioned[1;no]], how dare you!]
$footer[Requested by $username[$authorID]#$discriminator[$authorID];$authorAvatar]
$addTimestamp
$color[$getservervar[color]]

$onlyIf[$getglobaluservar[lock_equipped;$mentioned[1;no]]==false;{title:Click!}{description:You weren't able to rob them but you were able to remove their lock, if they don't equip a new lock you should be able to rob them soon >:)}{color:$getservervar[color]}]

$onlyIf[$getglobaluserVar[money;$mentioned[1;no]]>=6000;This user does not have above 6,000 BittyCoins, please try someone else.]

$onlyIf[$mentioned[1;no]!=$authorID;You can’t rob yourself, please mention someone else!]

$onlyIf[$isBot[$mentioned[1;no]]==false;You can’t rob a bot! Please mention someone else!]




$argsCheck[1;Please mention someone to rob!]
$suppresserrors[Please mention someone to rob!]
$globalcooldown[5m;Please wait %time% until using this again!]
`
})