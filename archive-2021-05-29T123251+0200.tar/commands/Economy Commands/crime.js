module.exports.command = ({
  name: "crime",
  code: `$globalCooldown[20m; you’ve already comitted a crime, please wait %time%!]
$setglobaluserVar[money;$sum[$getglobaluservar[money];$multi[$getGlobalUserVar[boostAmount];$random[500;3000]]]]
$author[🔫 Crime 🔪] 
$description[ **$username** $randomText[robbed a gas station;robbed a bank;hacked ROBLOX;hacked Discord and rewarded themself with Nitro;sold some drugs;stole Mom’s credit card], and earned **$random[5000;7000]** BittyCoins]
$color[$getServerVar[color]]
$footer[Requested by $username[$authorID]#$discriminator[$authorID];$authorAvatar]
$addTimestamp`
});