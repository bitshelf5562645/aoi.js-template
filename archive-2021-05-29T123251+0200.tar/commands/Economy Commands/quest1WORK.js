module.exports.command = ({
name: "work",
code: `$title[Congrats!]
$description[You have completed quest one! You have earned the BittyDollar BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[first_steps_bittybadge;$getglobaluservar[first_steps_emoji]]
$setglobaluservar[quest1done;true]
$onlyif[$getglobaluservar[quest1done]==false;]`
})