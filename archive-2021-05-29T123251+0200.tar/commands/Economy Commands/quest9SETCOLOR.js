module.exports.command = ({
name: "setcolor",
code: `$title[Congrats!]
$description[You have completed quest nine! You have earned the Rainbow BittyDollar BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[rainbow_bittybadge;$getglobaluservar[rainbow_emoji]]
$setglobaluservar[quest9done;true]
$onlyif[$getglobaluservar[quest9done]==false;]
$argscheck[1>;]`
})