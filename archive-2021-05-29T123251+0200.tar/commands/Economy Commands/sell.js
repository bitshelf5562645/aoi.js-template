module.exports.command = ({
  name: "sell",
  description: "This command allows you to sell the specified item, however the money made by selling it is half of what was used to buy it.",
  code: `
$setglobaluservar[money;$sum[$getglobaluserVar[money];$divide[$getVar[$replacetext[$message; ;_;-1]_cost];2]]]

$setglobaluserVar[$replacetext[$message; ;_;-1]_amount;$sum[$getglobaluserVar[$replacetext[$message; ;_;-1]_amount];-1]]


$title[SOLD!]
$description[You sold your $message for $numberseparator[$divide[$getVar[$replacetext[$message; ;_;-1]_cost];2];,] BittyCoins <:bittycoin:775690744719081483>]
$footer[requested by $username[$authorID]#$discriminator[$authorID];$authorAvatar]
$addTimestamp
$color[f1c40f]
$onlyIf[$getglobaluserVar[$replacetext[$message; ;_;-1]_amount]>=1;You cant sell something you don’t have!]
$suppressErrors[Please select a valid item!]`
})