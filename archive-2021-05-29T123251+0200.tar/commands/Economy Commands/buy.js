module.exports.command = ({
  name: "buy",
  code: `

$setGlobalUserVar[money;$sum[$getGlobalUserVar[money];-$getGlobalUserVar[$replaceText[$tolowercase[$message]; ;_;-1]_cost]]]
$title[transaction complete!]
$description[Purchase succesful
You bought the item: \`$tolowercase[$message]\`]
$footer[Requested by $userTag[$authorID];$authorAvatar]
$addTimestamp
$color[$getServerVar[color]]

$setGlobalUserVar[$replaceText[$tolowercase[$message]; ;_;-1]_amount;$sum[$getGlobalUserVar[$replaceText[$tolowercase[$message]; ;_;-1]_amount];1]]



$onlyIf[$getVar[$replaceText[$tolowercase[$message]; ;_;-1]_cost]<=$getGlobalUserVar[money];{title:Sad trombone!} {description:Insufficient funds! The purchase was unsuccessful!} {footer:Requested by $userTag[$authorID]} {color:FF0000}]
$suppresserrors[Please select a valid item to buy!]`
})