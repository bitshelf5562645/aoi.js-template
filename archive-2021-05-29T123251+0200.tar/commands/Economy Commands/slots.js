module.exports.command = ({
name: "slots",
code: `$author[$replaceText[$replaceText[$randomText[true;false];true;You Win];false;You Lose];$authorAvatar]
$title[$replaceText[$replaceText[$randomText[true;false];true;and got $numberseparator[5000;,] BittyCoins];false;lost $numberseparator[2000;,] BittyCoins]]
$description[$randomText[🍞;🍏;🍋;🍔;🥞] $randomText[🍔;🍏;🍞;🥞;🍋] $randomText[🥞;🍋;🍏;🍞;🍔]

$replaceText[$replaceText[$randomText[true;false];true;$randomText[🍞 🍞 🍞;🍔 🍔 🍔;🍋 🍋 🍋;🥞 🥞 🥞;🍏 🍏 🍏]];false;$randomText[🍏;🍔;🍞;🍋;🥞] $randomText[🍏;🥞;🍞;🍋;🍔] $randomText[🍔;🍋;🍞;🍏;🥞]]  **«**

$randomText[🍋;🍏;🍞;🍔;🥞] $randomText[🥞;🍞;🍔;🍋;🍏] $randomText[🍋;🍔;🥞;🍏;🍞]]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
$addTimestamp
$setGlobalUserVar[money;$replaceText[$replaceText[$randomText[true;false];false;$sub[$getGlobalUserVar[money];5000]];true;$sum[$getGlobalUserVar[money];5000]]]
$globalcooldown[5m;please wait %time% until using this again]
$onlyIf[$getGlobalUserVar[money]>=2000;You don't have enough money, you need 2000 BittyCoins or more.]`
})