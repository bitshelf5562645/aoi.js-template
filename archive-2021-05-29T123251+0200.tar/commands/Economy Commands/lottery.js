module.exports.command = ({
  name: "lottery",
  description: "This command allows you to have a small chance at winning a max of 40,000 BittyCoins!",
  code: `
$setglobaluserVar[ticket_amount;$sum[$getglobaluserVar[ticket_amount];-1]]

$setglobaluservar[whatyouwon;$randomText[0;0;0;0;0;0;0;0;0;0;100;1500;5000;20000;40000]]
$setVar[money;$sum[$randomText[0;0;0;0;0;0;0;0;0;0;100;1500;5000;20000;40000];$getglobaluserVar[money]]]

You used a lottery ticket!
You won... 
$editIn[500ms;You used a lottery ticket!
You won $randomText[0;0;0;0;0;0;0;0;0;0;100;1500;5000;20000;40000] BittyCoins]

$globalCooldown[1m;You can use another lottery ticket in **%time%**.]

$onlyIf[$getglobaluserVar[ticket_amount]>=1;You do not have a lottery ticket to use, use \`b!buy ticket\` to buy one.]`
})

//set <:Stonks_BittyBadge:827106087505362944> to this var

//set <a:Money_BittyBadge:827110108890136636> to the 200 k bittybadge var