module.exports.command = ({
name: "play",
aliases: "p",
code: `$title[Congrats!]
$description[You have completed quest five! You have earned the Vibin' BittyDollar BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[calendar_bittybadge;$getglobaluservar[calendar_emoji]]
$setglobaluservar[quest5done;true]
$onlyif[$getglobaluservar[quest5done]==false;]
$argscheck[1>;]`
})