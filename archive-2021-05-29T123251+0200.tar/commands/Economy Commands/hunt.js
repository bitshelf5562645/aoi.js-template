module.exports.command = ({
  name: "hunt",
  code: `
$color[$getServerVar[color]]
$title[Hunting!]
$description[<a:adv_frogGun:795239560296398879> You went hunting near BittyCity and caught a $randomText[deer;boar].]
$footer[requested by $username[$authorID]#$discriminator[$authorID];$authoravatar]
$addTimestamp

$setglobaluserVar[$randomText[deer;boar]_amount;$sum[$getglobaluserVar[$randomText[deer;boar]_amount];1]]

$globalCooldown[5m;you can hunt again in %time%.]
$onlyIf[$getglobaluserVar[hunting_rifle_amount]>=1;You can't hunt without a hunting rifle!]`

})