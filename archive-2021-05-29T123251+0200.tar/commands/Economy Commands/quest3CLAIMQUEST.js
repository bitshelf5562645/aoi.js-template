module.exports.command = ({
name: "claimquest",
code: `$title[Done!]
$description[You claimed quest three, you earned the stonks Bittybadge, it has been added to your badges automatically!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[actual_stonks_bittybadge;$getglobaluservar[actual_stonks_emoji]]
$setglobaluservar[quest3done;true]
$onlyif[$getglobaluservar[quest3done]==false;You have already completed and claimed the rewards of this quest!]
$onlyif[$getglobaluservar[money]>=200000;You do not have enough BittyCoins.]
$onlyif[$checkcontains[$message;three]==true;]`
})