module.exports.command = ({
name: "sell",
code: `$title[Congrats!]
$description[You have completed quest seven! You have earned the Half a BittyDollar BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[half_bittybadge;$getglobaluservar[half_emoji]]
$setglobaluservar[quest7done;true]
$onlyif[$getglobaluservar[quest7done]==false;]
$onlyIf[$getglobaluserVar[$replacetext[$message; ;_;-1]_amount]>=1;]
$argscheck[1>;]
$suppresserrors`
})