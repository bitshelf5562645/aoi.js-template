module.exports.command = ({
  name: "stats",
  code: `$color[$getservervar[color]]
$title[$usertag[$mentioned[1;yes]]'s stats]
$description[Statistics and Inventory]
$addField[User Inventory;
**BittyCoins:** $numberSeparator[$getglobaluserVar[money;$mentioned[1;yes]];,]
**locks**: $getglobaluserVar[lock_amount;$mentioned[1;yes]]
**trout**: $getglobaluserVar[trout_amount;$mentioned[1;yes]]
**salmon**: $getglobaluserVar[salmon_amount;$mentioned[1;yes]]
**deer**: $getglobaluserVar[deer_amount;$mentioned[1;yes]]
**boar**: $getglobaluserVar[boar_amount;$mentioned[1;yes]]
**Bittytrophies:** $getglobaluservar[bittytrophy_amount;$mentioned[1;yes]]

**BittyBadges:**
$getglobaluservar[easter_egg_bittybadge;$mentioned[1;yes]] $getglobaluservar[first_steps_bittybadge;$mentioned[1;yes]] $getglobaluservar[calendar_bittybadge;$mentioned[1;yes]] $getglobaluservar[actual_stonks_bittybadge;$mentioned[1;yes]]  $getglobaluservar[gift_bittybadge;$mentioned[1;yes]] $getglobaluservar[music_bittybadge;$mentioned[1;yes]] $getglobaluservar[incognito_bittybadge;$mentioned[1;yes]] $getglobaluservar[half_bittybadge;$mentioned[1;yes]] $getglobaluservar[roulette_bittybadge;$mentioned[1;yes]] $getglobaluservar[rainbow_bittybadge;$mentioned[1;yes]] $getglobaluservar[lottery_bittybadge;$mentioned[1;yes]]
$getglobaluservar[brain_bittybadge;$mentioned[1;yes]] $getglobaluservar[prestige_bittybadge];$mentioned[1;yes]] $getglobaluservar[star_coin_bittybadge;$mentioned[1;yes]]
$footer[Requested by $username[$authorID]#$discriminator[$authorID];$authoravatar]
$addTimestamp`
})