module.exports.command = ({
name: "claimquest",
code: `$title[Congrats!]
$description[You have completed quest twelve, the very last quest! You have earned the Restart BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[restart_bittybadge;$getglobaluservar[restart_emoji]]
$setglobaluservar[quest12done;true]
$onlyif[$getglobaluservar[quest12done]==false;]
$onlyif[$getglobaluservar[prestiges]>=1;You haven't prestiged yet!]
$onlyif[$checkcontains[$message;twelve]==true;]`
})