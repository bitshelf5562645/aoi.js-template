module.exports.command = ({
name: "grantquest",
code: `$title[Done!]
$description[Congrats! $usertag[$finduser[$message]], $usertag[$botownerid] has granted you the completion of quest eleven!]
$color[$getservervar[color]]
$setglobaluservar[brain_bittybadge;$getglobaluservar[brain_emoji];$finduser[$message]]
$setglobaluservar[quest11done;true;$finduser[$message]]

$onlyforids[$botownerid;Owner Only!]`
})