module.exports.command = ({
  name: "reset",
  description: `This command deletes you from the dbd.db database.`,
  code: `$title[Reset complete!]
  $description[I have removed your data!]
  $color[$getservervar[color]]
  $djsEval[client.db.delete({varID: "$authorID"})]`
})