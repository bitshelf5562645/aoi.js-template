module.exports.command = ({
name: "lottery",
code: `
$title[congrats!]
$description[You completed quest ten! Congrats you earned the $getglobaluservar[actual_stonks_emoji] BittyBadge]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$color[$getservervar[color]]

$setglobaluservar[actual_stonks_bittybadge;$getglobaluservar[actual_stonks_emoji]]
$onlyif[$getglobaluservar[whatyouwon]==40000;]


$onlyif[$getglobaluservar[actual_stonks_bittybadge]!=$getglobaluservar[actual_stonks_emoji];]
$globalCooldown[1m;]

$onlyIf[$getglobaluserVar[ticket_amount]>=1;]
$wait[1s]`
});