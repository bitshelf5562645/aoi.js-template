module.exports.command = ({
name: "quests",
code: `$title[Your quests!]
$description[
$addfield[Completed?;1 $getglobaluservar[quest1done].

2 $getglobaluservar[quest2done].

3 $getglobaluservar[quest3done].

4 $getglobaluservar[quest4done].

5 $getglobaluservar[quest5done].

6 $getglobaluservar[quest6done].

7 $getglobaluservar[quest7done].

8 $getglobaluservar[quest8done].

9 $getglobaluservar[quest9done].

10 $getglobaluservar[quest10done].

11 $getglobaluservar[quest11done].

12 $getglobaluservar[quest12done].;no]
$addfield[Rewards?;1 Bittydollar BittyBadge

2 BittyCalendar BittyBadge.

3 Stonks BittyBadge.

4 BittyGift BittyBadge.

5 Vibin' BittyDollar BittyBadge.

6 Incognito BittyDollar.

7 Half of a BittyDollar.

8 Roulette BittyDollar

9 Rainbow DittyDollar.

10 Two BittyDollars BittyBadge.

11 BittyBrain BittyBadge.

12 restart BittyBadge.;no]
$addfield[Quests:;Quest one: \`Use B!work for the first time.\`

Quest two: \`claim your monthly money.\`

Quest three: \`Reach 200K BittyCoins.\`

Quest four: \`Gift someone something.\`

Quest five: \`Play some music for the first time.\`

Quest six: \`Read the Privacy Policy\`

Quest seven: \`Sell an item.\`

Quest eight: \`Bet some money with $getservervar[prefix]bet\`

Quest nine: \`Customize the embed color for your server.\`

Quest ten: \`Win 40,000 BittyCoins with $getservervar[prefix]lottery\`

Quest eleven: \`Suggest a command and get it added.\`

Quest twelve: \`Prestige.\`;yes]

For certain quests you need to use $getservervar[prefix]claimquest to claim the reward of the quest, these are quest three and twelve.]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
`
});