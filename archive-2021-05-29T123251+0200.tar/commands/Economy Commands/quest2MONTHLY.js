module.exports.command = ({
name: "monthly",
code: `$title[Congrats!]
$description[You have completed quest two! You have earned the BittyCalendar BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[calendar_bittybadge;$getglobaluservar[calendar_emoji]]
$setglobaluservar[quest2done;true]
$onlyif[$getglobaluservar[quest2done]==false;]`
})