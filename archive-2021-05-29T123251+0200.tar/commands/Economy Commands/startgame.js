module.exports.command = ({
name: "start",
code: `$if[$tolowercase[$message]==kirby]
$title[Kirby!]
$description[You started playing Kirby, you $getglobaluservar[kirby_leftoff].

As you walked through $getglobaluservar[kirby_stage] you encountered a $tolocaleuppercase[$randomtext[waddle dee;waddle doo;birdon;blade knight;cappy;chilly;rocky;simirror]]

Will you **inhale**, **attack** or **flee**?]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp

$setglobaluservar[kirby_enemy;$randomtext[waddle dee;waddle doo;birdon;blade knight;cappy;chilly;rocky;simirror]]
$setglobaluservar[kirby_leftoff;you started playing where you left off]
$awaitmessages[$authorid;5m;inhale,flee,attack;inhale,flee,attackpower]
$onlyif[$getglobaluservar[kirby_amount]>=1;You don't have kirby!]

$elseif[$tolowercase[$message]==plants]
$description[You started playing Plants VS Zombies: Coin warfare.
You started playing a match of Bit]
$endelseif
$endif
`
})