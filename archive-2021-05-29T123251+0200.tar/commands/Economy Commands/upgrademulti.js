module.exports.command = ({
  name: "upgrademulti",
  code: `$title[Upgraded!]
$description[You Upgraded your bank with a $message multiplier!]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
  
  $setGlobalUserVar[money;$sum[$getGlobalUserVar[money];-$getGlobalUserVar[multi_$replaceText[$message; ;_;-1]_cost]]]
$setGlobalUserVar[deposit_max;$multi[$getglobaluservar[deposit_max];$getGlobalUserVar[$replaceText[$message; ;_;-1]_multi]]]
$onlyIf[$getglobaluserVar[multi_$replaceText[$message; ;_;-1]_cost]<$getGlobalUserVar[money];{title:Sad trombone!} {description:Insufficient funds! The purchase was unsuccessful!} {footer:Requested by $userTag[$authorID]} {color:FF0000}]
$suppressErrors[Please select a valid upgrade!]

`
})