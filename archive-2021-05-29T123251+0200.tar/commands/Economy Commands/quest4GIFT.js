module.exports.command = ({
name: "gift",
code: `$title[Congrats!]
$description[You have completed quest four! You have earned the BittyGift BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[gift_bittybadge;$getglobaluservar[gift_emoji]]
$setglobaluservar[quest4done;true]
$onlyif[$getglobaluservar[quest4done]==false;]
$argscheck[1>;]`

});