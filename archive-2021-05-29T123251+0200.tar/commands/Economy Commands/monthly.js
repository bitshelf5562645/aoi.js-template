module.exports.command = ({
    name: "monthly",
    description: `This command will give you your monthly money.`,
  code: `$title[monthly money!]
$thumbnail[$authorAvatar]
$addField[Claimed!;You succesfully claimed a months worth of 80,000 BittyCoins!]
$footer[requested by $usertag[$authorID]]
$addTimestamp
$color[$getServerVar[color]]

$setGlobalUserVar[money;$sum[$getGlobalUserVar[money];80000]]

$globalCooldown[30d; wait for **%time%** to claim your money again]`
})