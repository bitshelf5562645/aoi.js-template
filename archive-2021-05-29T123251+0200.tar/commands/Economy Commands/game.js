module.exports.command = ({
name: "game",
code: `$title[Hmmmmm... What To Pick?]
$description[You booted up your BittyCoinsole and logged into your account $usernameForTheWin. You looked at the home screen, what game do you wish to play?
You can always use $getservervar[prefix]gamestore to purchase any games!
$addfield[Subnautica: Below Zero?;$getglobaluservar[subnautica_unlocked];yes]
$addfield[MineCraft?;$getglobaluservar[minecraft_unlocked];yes] 
$addfield[Kirby: The disappearance of the BittyCoin?;$getglobaluservar[kirby_unlocked];yes]
$addfield[Friday Night Funkin'?;$getglobaluservar[friday_unlocked];yes]
$addfield[Call Of Duty: Coin Ops?;$getglobaluservar[call_unlocked];yes]
$addfield[Plants VS Zombies: Coin Warfare?;$getglobaluservar[plants_unlocked];yes]]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$onlyif[$getglobaluservar[bittycoinsole_amount]>=1;You don't own a BittyCoinsole!]`
})