module.exports.command = ({
name: "balance",
aliases: ["bal"],
code: `$title[Balance!]
$description[$username[$mentioned[1;yes]] has $numberSeparator[$getGlobalUserVar[money;$mentioned[1;yes]];,] BittyCoins in their wallet

$username[$mentioned[1;yes]] has $numberSeparator[$getGlobalUserVar[deposited;$mentioned[1;yes]];,] BittyCoins deposited in their bank!

$username[$mentioned[1;yes]] can deposit a max of $numberseparator[$getglobaluservar[deposit_max;$mentioned[1;yes]];,] BittyCoins in their bank!]
$color[$getServerVar[color]] 

$footer[Requested by $username[$authorID]#$discriminator[$authorID]] 

$addTimeStamp 

`
});