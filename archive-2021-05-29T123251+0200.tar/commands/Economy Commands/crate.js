module.exports.command = ({
name: "moneycrate",
code: `You opened your crate, you got: $editin[300ms;You opened your crate, you got: $randomtext[100;250;500;1000;2000;8000;4000] Bittycoins;You opened your crate, you got: $randomtext[250;100;500;1000;2000;4000;8000] Bittycoins;You opened your crate, you got: $randomtext[100;500;250;1000;2000;4000;8000] Bittycoins;You opened your crate, you got: $randomtext[500;250;100;1000;2000;4000;8000] Bittycoins;You opened your crate, you got: $randomtext[100;250;500;1000;8000;4000;2000] Bittycoins;You opened your crate, you got: $randomtext[100;250;500;8000;4000;2000;1000] Bittycoins]

$setglobaluservar[money;$sum[$getglobaluservar[money];$randomtext[100;250;500;8000;4000;2000;1000]]]

$setglobaluservar[money_crate_amount;$sum[$getglobaluservar[money_crate_amount];-1]]

$onlyif[$getglobaluservar[money_crate_amount]>=1;{title:Oops!}{description:You don't have a money crate!}{color:$getservervar[color]}]
`
})