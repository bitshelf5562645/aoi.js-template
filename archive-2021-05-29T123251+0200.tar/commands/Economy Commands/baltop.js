module.exports.command = ({
  name: "balance top",
  aliases: ["baltop", "btop", "bt", "balt"],
  code: `$title[Top BittyCoin leaderboard]
$description[$textSplitMap[ns]]
$textSplit[$globalUserLeaderBoard[money;asc;{top}) {username} : ❥❦❧{value}];\n]
$color[$getservervar[color]]`
})