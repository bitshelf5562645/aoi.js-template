module.exports.command = ({
name: "upgradesum",
code: `$title[Upgraded!]
$description[You Upgraded your bank with a $message sum!]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]

$setGlobalUserVar[money;$sum[$getGlobalUserVar[money];-$getGlobalUserVar[sum_$replaceText[$message; ;_;-1]_cost]]]

$setGlobalUserVar[deposit_max;$sum[$getglobaluservar[deposit_max];$getGlobalUserVar[$replaceText[$message; ;_;-1]_sum]]]

$onlyIf[$getglobaluserVar[sum_$replaceText[$message; ;_;-1]_cost]<$getGlobalUserVar[money];{title:Sad trombone!} {description:Insufficient funds! The upgrade was unsuccessful!} {footer:Requested by $userTag[$authorID]} {color:FF0000}]
$suppressErrors[Please select a valid upgrade!]`
})