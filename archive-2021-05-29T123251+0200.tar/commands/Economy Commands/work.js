module.exports.command = ({
  name: "work",
  description: `This command will earn you some BittyCoins by working.`,
  code: `$title[Work!] 
  $description[You worked for $random[3;6] hours and earned $numberSeparator[$multi[$getGlobalUserVar[prestige_multiplier];$random[500;3000]];,] BittyCoins!] 
  $footer[Requested by $username[$authorID]#$discriminator[$authorID]] 
  $addTimeStamp 
  
  $setGlobalUserVar[money;$sum[$getGlobalUserVar[money];$multi[$getGlobalUserVar[prestige_multiplier];$random[500;3000]]]] 
  
  $color[$getServerVar[color]] 
  
  $globalCooldown[5m;Please wait %time% until using this again!]`
});
									
//so i just discovered my prestige command is finished but i havent made it boost yet, well not in the correct way