module.exports.command = ({
name: "claimbadge",
code: `$title[Claimed!]
$description[You claimed the limited time $message BittyBadge]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
$addtimestamp
$setglobaluservar[$replacetext[$message; ;_;-1]_bittybadge;$getglobaluservar[$replacetext[$message; ;_;-1]_emoji]]
$setglobaluservar[$replacetext[$message; ;_;-1]_amount;$sum[$getglobaluservar[$replacetext[$message; ;_;-1]_amount];-1]]
$onlyif[$getglobaluservar[$replacetext[$message; ;_;-1]_amount]>=1;You can't claim a BittyBadge without the item for it!]
$onlyif[$getglobaluservar[$replacetext[$message; ;_;-1]_bittybadge]!=$getglobaluservar[$replacetext[$message; ;_;-1]_emoji];You have already claimed that BittyBadge!
$suppresserrors[$message BittyBadge does not exist! Wrong input!]]
`
})