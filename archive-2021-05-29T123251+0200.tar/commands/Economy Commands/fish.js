module.exports.command = ({
  name: "fish",
  description: `This command allows you to fish.`,
  code: `

$color[$getservervar[color]]
$title[Gone fishing!]
$description[<:fishingkirb:794587728397336616> You went fishing in a body of water near BitCreate and caught a $randomText[trout;salmon]]
$footer[requested by $username[$authorID]#$discriminator[$authorID];$authorAvatar]
$addTimestamp
$globalCooldown[5m;you can fish again in %time%.]

$setglobaluserVar[$randomText[trout;salmon]_amount;$sum[$getglobaluserVar[$randomText[trout;salmon]_amount];1]]
$onlyIf[$getglobaluserVar[fishing_rod_amount]>=1;You need a fishing rod for this!]`
})