module.exports.command = ({
name: "purchase",
code: `$title[Have Fun!]
$description[You bought \`$getglobaluservar[$message[1]_name]\`, use $getservervar[prefix]start $message[1] to play it, Have fun playing $getglobaluservar[$message[1]_name]]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$setglobaluservar[$tolowercase[$message[1]]_amount;1]
$onlyif[$getglobaluservar[$tolowercase[$message[1]]_amount]==0;You've already bought this game!]
$onlyif[$getglobaluservar[money]>=$getglobaluservar[$tolowercase[$message[1]]_cost];You don't have enough BittyCoins!]`
})