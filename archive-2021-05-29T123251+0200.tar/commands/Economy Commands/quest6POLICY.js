module.exports.command = ({
name: "policy",
code: `$title[Congrats!]
$description[You have completed quest six! You have earned the Incognito BittyDollar BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[incognito_bittybadge;$getglobaluservar[incognito_emoji]]
$setglobaluservar[quest6done;true]
$onlyif[$getglobaluservar[quest6done]==false;]`
})