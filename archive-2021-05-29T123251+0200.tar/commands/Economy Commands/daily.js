module.exports.command = ({
  name: "daily",
  code: `$title[Daily money!]
$thumbnail[$authorAvatar]
$addField[Claimed!;You succesfully claimed a days worth of 5000 BittyCoins!]
$footer[requested by $usertag[$authorID]]
$addTimestamp
$color[$getServerVar[color]]

$setGlobalUserVar[money;$sum[$getGlobalUserVar[money];5000]]

$globalCooldown[1d; wait for **%time%** to claim your money again]`
})