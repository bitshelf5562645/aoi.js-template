module.exports.command = ({
name: "bet",
code: `$title[Congrats!]
$description[You have completed quest eight! You have earned the BittyRoulette BittyBadge!]
$footer[Requested by $usertag;$authoravatar]
$color[$getservervar[color]]
$addtimestamp
$setglobaluservar[roulette_bittybadge;$getglobaluservar[roulette_emoji]]
$setglobaluservar[quest8done;true]
$onlyif[$getglobaluservar[quest8done]==false;]
$argscheck[1>;]`
})