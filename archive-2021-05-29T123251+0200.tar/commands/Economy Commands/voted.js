module.exports.command = ({
nonPrefixed: true,
name: "$alwaysExecute",
code: `50K BittyCoins have been given to $usertag[$findUser[$message;no]]
$setglobaluservar[money;$sum[50000;$getglobaluservar[money;$findUser[$message;no]]];$findUser[$message;no]]
$senddm[$findUser[$message;no];{title:Thanks!}{description:Thanks for supporting my creator by voting for me on top.gg! You earned 50k Bittycoins by doing so!}{color:f1c40f}]
$onlyIf[$findUser[$message;no]!=undefined;User not found]
$onlyforchannels[823938647819550771;] $cooldown[2s]`
})