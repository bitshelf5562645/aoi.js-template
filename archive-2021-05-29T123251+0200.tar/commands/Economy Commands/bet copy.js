module.exports.command = ({
name: "bet",
code: `$title[betting!]
$if[$message[1]==$random[1;30]]
$description[You started betting, the ball can land in 30 spots, $message[2] on the ball landing in $message[1], it did indeed land in spot $random[1;30], you won $numberseparator[$multi[$message[2];4];,] BittyCoins]
$setglobaluservar[money;$sum[$getglobaluservar[money];$multi[$message[2];4]]]
$elseif[$message[1]!=$random[1;30]]
$description[You started betting, the ball can land in 30 spots, $message[2] on the ball landing in $message[1], it landed in spot $random[1;30], you lost $numberseparator[$divide[$message[2];2];,] BittyCoins]
$setglobaluservar[money;$sum[$getglobaluservar[money];-$divide[$message[2];2]]]
$endelseif
$endif
$color[$getservervar[color]]
$globalcooldown[20m;Please wait %time% until betting again!]
$argscheck[2;Usage: \`$getservervar[prefix]bet <spot between 1 and 30> <amount you wanna bet>\`]
$onlyif[$getglobaluservar[money]>=$message[2];You don't have enough BittyCoins to bet.]
$onlyif[$checkcontains[$message;1;2;3;4;5;6;7;8;9;0]==true;Usage: \`$getservervar[prefix]bet <spot between 1 and 30> <amount you wanna bet>\`]
$onlyif[$checkcontains[$message;q;a;z;x;s;w;e;d;c;v;f;r;t;g;b;n;h;y;u;j;m;k;i;l;o;p]==false;]
$onlyif[$message[1]<=30;You can't choose a spot above 30!]
$suppresserrors[Error: Wrong input]`
})