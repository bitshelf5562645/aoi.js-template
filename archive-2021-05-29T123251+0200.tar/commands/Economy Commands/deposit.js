module.exports.command = ({
  name: "deposit",
  description: `This command allows you to deposit a max of 10,000 BittyCoins, this command has a cooldown of 10 minutes, you can upgrade your bank (soon).`,
  aliases: ["dep"],
  code: `$title[Deposited!]
  $description[You deposited $numberSeparator[$message;,] BittyCoins]
  $footer[Requested by $usertag;$authoravatar]
  $addtimestamp
  $color[$getservervar[color]]
  $setglobaluservar[deposited;$sum[$getglobaluservar[deposited];$message]]
  $setglobaluservar[money;$sum[$getglobaluservar[money];-$message]]
$globalcooldown[10m;You can deposit BittyCoins in %time%]
  $onlyIf[$message<=$getglobaluservar[deposit_max];You can't deposit more than $numberseparator[$getglobaluservar[deposit_max];,] Bittycoins, to do this you need to upgrade your bank!]
  $onlyif[$sum[$message;$getglobaluservar[deposited]]<=$getglobaluservar[deposit_max];You can't deposit more than $numberSeparator[$getglobaluservar[deposit_max];,] BittyCoins yet!]
  $onlyif[$message[1]<=$getglobaluservar[money];You can't deposit more than you have!]
  $argscheck[1;Please only send the amount of BittyCoins you want to deposit!]
  $onlyIf[$checkContains[$message;1;2;3;4;5;6;7;8;9;0]==true;]
  $onlyIf[$checkcontains[$message;q;w;e;r;t;y;u;i;o;p;a;s;d;f;g;h;j;k;l;z;x;c;v;b;n;m]==false;Please only send the amount of Bittycoins you want to deposit!]
  $argscheck[1;Please choose the amount you want to deposit!]
  `
})
