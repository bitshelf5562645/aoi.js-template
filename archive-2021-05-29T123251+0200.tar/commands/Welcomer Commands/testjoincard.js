module.exports.command = ({
  name: "testjoincard",
  aliases: ["tjc"],
  code: `<@$authorID>
   $title[Everyone welcome $usertag[$authorID]]
  $description[$getServerVar[welcomeMessage]]
  $image[https://api.xzusfin.repl.co/card?avatar=$replaceText[$authorAvatar;.webp;.png;1]&middle=welcome&name=$replaceText[$replaceText[$username[$authorID]#$discriminator[$authorID];#;%23;-1]; ;%20;-1]&bottom=$replaceText[$getServerVar[welbtext]; ;%20;-1]&background=$getServerVar[custombg]&text=%23$getServerVar[tcolor]&avatarborder=%23$getServerVar[aborder]&avatarbg=%23$getServerVar[avbdrop]]
  $addTimestamp
  $thumbnail[$serverIcon?size=2048]
$color[$getServerVar[color]]`
})