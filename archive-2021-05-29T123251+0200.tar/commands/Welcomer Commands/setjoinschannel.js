module.exports.command = ({
    name: "setjoinchannel",
    aliases: "sjc",
    code: `$title[join logs!]
$description[I will now log joins in this server in <#$mentionedChannels[1;yes]>]
$footer[join logs are now enabled]
$color[$getServerVar[color]]
$setServerVar[welcome;$mentionedChannels[1;yes]]
$onlyPerms[managechannels;You need manage channels permission for this!]
$onlyIf[$channelExists[$mentionedChannels[1;yes]]==true;Please mention a valid channel!]`
});