module.exports.awaitedCommand = ({
name: "yes",
code: `$title[No going back now!]
$description[You used a prestige, all your wallet money, deposited money and all bank upgrades have been sacrificed for this, you now have a $getglobaluservar[prestige_multiplier] multiplier]
$color[$getservervar[color]]
$setglobaluservar[prestiges;$sum[$getglobaluservar[prestiges];1]]
$footer[Requested by $usertag;$authoravatar]
$setglobaluservar[prestige_multiplier;$sum[$getglobaluservar[prestige_multiplier];1]]
$setglobaluservar[prestige_required_money;$sum[$getglobaluservar[prestige_required_money];$multi[500000;$getglobaluservar[prestige_multiplier]]]
$setglobaluservar[money;0]
$setglobaluservar[fishing_rod_amount;0]
$setglobaluservar[hunting_rifle_amount;0]
$setglobaluservar[deposit_max;10000]
$setglobaluservar[deposited;0]
$setglobaluservar[ticket_amount;0]
$setglobaluservar[lock_amount;0]
$setglobaluservar[trout_amount;0]
$setglobaluservar[salmon_amount;0]
$setglobaluservar[deer_amount;0]
$setglobaluservar[boar_amount;0]
$setglobaluservar[lock_equipped;false]
$thumbnail[$useravatar[$clientID]]
$onlyif[$getglobaluservar[money]>=$getglobaluservar[prestige_required_money];You can't prestige yet, you don't have enough BittyCoins, you need $numberseparator[$getglobaluservar[prestige_required_money];,] BittyCoins]`
});



//now to make it actually change the multiplier variable
//now to add some more decorations to the output
//now to make it so you can't prestige if you're not far enough. 
//now we'll make it reset all items, money etc.




//now to make the cancel command