module.exports.awaitedCommand = ({
	name: 'music',
	code: ` $editMessage[$message[1];{title:music help!} {description:\`$getservervar[prefix]play / $getservervar[prefix]p\`, play the specified song.
\`$getservervar[prefix]disconnect / $getservervar[prefix]dc / $getservervar[prefix]stop\`
stop playing music and leave the voice channel.
\`$getservervar[prefix]skip\`
skip the current track.
\`$getservervar[prefix]loop\`
Get a menu where you can choose to loop the queue or loop the song, the bot will await your message so make sure to read the choices it gives.
\`$getservervar[prefix]lyrics / $getservervar[prefix]l\`
fetch the lyrics of the current playing song.
\`$getservervar[prefix]pause\`
pause the current playing song.
\`$getservervar[prefix]\`resume
resume the paused song.
\`$getservervar[prefix]q / $getservervar[prefix]queue\`
get the queue, contains thumbnail of the current song, total duration of the song, remaining duration of the song and of course the queue, send the page number after the command to see the page you specified.
\`$getservervar[prefix]volume\`, change the volume to a max of 150%.
\`$getservervar[prefix]removesong\` / \`$getservervar[prefix]rs\`, remove the specified song from the queue.
    
<:back:806285459348783134> - back
  }{color:$getServerVar[color]}{image:https://cdn.discordapp.com/attachments/760598463984566274/841648648613265408/image0.jpg}] `
});

