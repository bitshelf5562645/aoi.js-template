module.exports.awaitedCommand = ({
	name: 'misc',
	code: ` $editMessage[$message[1];{title:Misc help!} {description:\`$getservervar[prefix]setprefix\`
  change the server's prefix for the bot.
\`$getservervar[prefix]sjc / $getservervar[prefix]setjoinschannel\`
use this command to set the mentioned channel to the channel that gets logged with welcome and goodbye messages.
\`$getservervar[prefix]chatbot on / $getservervar[prefix]cb on\`, can be used to enable chatbot mode, if no channel is mentioned after the command the channel the command is used in will be used as the chatbot channel.
\`$getservervar[prefix]chatbot off / $getservervar[prefix]cb off\`, can be used to disable chatbot mode.
\`$getservervar[prefix]i / $getservervar[prefix]inv / $getservervar[prefix]invite\`, invite the bot to your server.
\`$getservervar[prefix]support\`, get the invite link to the support server.
\`$getservervar[prefix]servers\`, fetch how many servers the bot is in and how many users it has.
\`$getservervar[prefix]policy\`, get the privacy policy of the bot.
\`$getservervar[prefix]reset\`, reset your data, read the policy for info.
\`$getservervar[prefix]userinfo\`, shows the user info of you or the mentioned user in the server.
\`$getservervar[prefix]botlists / $getservervar[prefix]bl\`, get a list of the botlists the bot is in.
\`$getservervar[prefix]gencaptcha\`, generate a captcha code.
\`$getservervar[prefix]captcha\`, get the generated captcha code, send the code you see to get verified.
\`$getservervar[prefix]setverifrole / $getservervar[prefix]svr\`, set the verified role for the server.
\`$getservervar[prefix]reportbug\`, report a bug in the bot.
\`$getservervar[prefix]suggest\`, suggest a command for the bot.
\`$getservervar[prefix]covid\`, shows the covid cases for your specified country.
\`$getservervar[prefix]translate\`, translates your specified message to English.
\`$getservervar[prefix]npm\`, search npm for the package in your message.
\`$getservervar[prefix]faq\`, the FAQ's.
\`$getservervar[prefix]botinfo\`, some general info about the bot.
\`$getservervar[prefix]urban\`, search the urban dictionary for your message.

    
<:back:806285459348783134> - back
  }{color:$getServerVar[color]}{image:https://cdn.discordapp.com/attachments/760598463984566274/841648648613265408/image0.jpg}] `
});

