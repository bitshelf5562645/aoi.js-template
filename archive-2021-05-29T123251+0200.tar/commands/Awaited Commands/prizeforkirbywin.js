module.exports.awaitedCommand = ({
name: "prizeforwinningkirby",
code: `$setglobaluservar[star_coin_bittybadge;$getglobaluservar[star_coin_emoji]]
$setglobaluservar[money;$sum[$getglobaluservar[money];20000]]`
})