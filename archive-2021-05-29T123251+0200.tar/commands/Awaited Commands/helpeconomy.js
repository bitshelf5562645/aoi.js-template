module.exports.awaitedCommand = ({
	name: 'betaconomy',
	code: ` $editMessage[$message[1];{title:Bittyconomy help!} {description:\`$getservervar[prefix]work\`
work to earn some money.
\`$getservervar[prefix]balance / $getservervar[prefix]bal\`, outputs your balance.
\`$getservervar[prefix]shop\`, get the items that you can buy.
\`$getservervar[prefix]buy\`, buy one of the items in the shop.
\`$getservervar[prefix]crime\`, commit a crime and earn some money.
\`$getservervar[prefix]daily\`, claim your daily money.
\`$getservervar[prefix]weekly\`, claim your monthly money.
\`$getservervar[prefix]monthly\`, claim your monthly money.
\`$getservervar[prefix]pay\`, pay the mentioned user the specified amount of money.
\`$getservervar[prefix]lock\`, put a lock on your wallet, protect yourself from one rob attempt.
\`$getservervar[prefix]rob\`, rob someone, when the user has a lock equipped it will remove the lock for the next rob attempt.
\`$getservervar[prefix]beg\`, beg for some money.
\`$getservervar[prefix]deposit / $getservervar[prefix]dep\`, deposit the sepcified amount of money.
\`$getservervar[prefix]withdraw / $getservervar[prefix]with\`, withdraw the specified amount of money from your bank.
\`$getservervar[prefix]hunt\`, hunt for some animals.
\`$getservervar[prefix]fish\`, go fishing.
\`$getservervar[prefix]sell\`, sell an item for the half the price it's sold in the store for.
\`$getservervar[prefix]stats\`, get your user stats in the bittyconomy system.
\`$getservervar[prefix]lottery\`, use a lottery ticket for a small chance to win 40,000 BittyCoins.
\`$getservervar[prefix]upgradelist\`, get the list of the available bank upgrades.
\`$getservervar[prefix]upgradesum\`, upgrade your bank with a sum upgrade.
\`$getservervar[prefix]upgrademulti\`, upgrade your bank with a multiplier. 
\`$getservervar[prefix]story\`, get the story of bittyconomy, this is needed to understand certain commands.
\`$getservervar[prefix]prestige\`, a fresh start, lose everything for a boost, every prestige increases the boost by one, the price of the prestige also increases.
\`$getservervar[prefix]bet\`, bet money on a specific spot.
\`$getservervar[prefix]slots\`, a slots machine, you have to specify how much BittyCoins you will use for this, if you win you'll get 5000 BittyCoins, if you lose You'll lose 2000 BittyCoins.
\`$getservervar[prefix]quests\`, get a list of all quests.
\`$getservervar[prefix]claimquest\`, claim the rewards of a quest, only works for certain quests.
\`$getservervar[prefix]gift\`, gift someone an item that you own.
**experimental commands**
\`$getservervar[prefix]moneycrate\`, open a money crate.

<:back:806285459348783134> - back
  }{color:$getServerVar[color]}{image:https://cdn.discordapp.com/attachments/760598463984566274/841648648613265408/image0.jpg}] `
});

