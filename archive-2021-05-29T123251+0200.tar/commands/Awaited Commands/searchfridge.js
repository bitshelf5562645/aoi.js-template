module.exports.awaitedCommand = ({
  name: "fridge",
  code: `$title[This is cold!]
  $description[You looked in the fridge and found some meat which you sold for $numberseparator[$random[1000;4000];,] BittyCoins!]
  $color[$getservervar[color]]
  $setglobaluservar[money;$sum[$getglobaluservar[money];$random[1000;4000]]]
  $onlyIf[$checkContains[$getuservar[options];fridge]==true;]
  `
})

