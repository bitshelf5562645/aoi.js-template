module.exports.awaitedCommand = ({
name: "attackpower",
code: `$if[$getglobaluservar[kirby_progress]==5]
$setglobaluservar[kirby_enemy;$randomtext[waddle dee;waddle doo;birdon;blade knight;cappy;chilly;rocky;simirror]]
$title[POYO!]
$description[You attacked the $getglobaluservar[kirby_enemy].

As you continued walking through $getglobaluservar[kirby_stage] you encountered $getglobaluservar[kirby_boss]!

Will you eject your current ability and **spit** it at him or **attack**?]

$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$setglobaluservar[kirby_progress;0]
$awaitmessages[$authorid;5m;spit,attack;spit,attackboss]

$else

$setglobaluservar[kirby_enemy;$randomtext[waddle dee;waddle doo;birdon;blade knight;cappy;chilly;rocky;simirror]]
$title[POYO!]
$description[You attacked the $getglobaluservar[kirby_enemy]. 

As you walked through $getglobaluservar[kirby_stage] you encountered a $randomtext[waddle dee;waddle doo;birdon;blade knight;cappy;chilly;rocky;simirror]

Will you eject your current ability and **inhale**, **attack** or **flee**?]

$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$setglobaluservar[kirby_progress;$sum[$getglobaluservar[kirby_progress];1]]
$awaitmessages[$authorid;5m;inhale,flee,attack;inhale,flee,attackpower]
$endif`
})