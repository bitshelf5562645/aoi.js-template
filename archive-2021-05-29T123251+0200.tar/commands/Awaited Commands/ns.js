module.exports.awaitedCommand = ({
name: "ns",
code: `$splitText[1] $numberSeparator[$splitText[2]]
$textSplit[$message[1];❥❦❧]`
})