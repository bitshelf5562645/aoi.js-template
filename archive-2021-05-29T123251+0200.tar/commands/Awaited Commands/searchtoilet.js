module.exports.awaitedCommand = ({
  name: "toilet",
  code: `$title[Just why?]
  $description[You stick your hand in the toilet, you found nothing, what did you expect? gold? no!]
  $color[$getservervar[color]]
  $onlyIf[$checkContains[$getuservar[options];toilet]==true;]
  `
})

