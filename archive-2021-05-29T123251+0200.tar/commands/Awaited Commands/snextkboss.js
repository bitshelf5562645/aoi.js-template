module.exports.awaitedCommand = ({
name: "setnextkirbyboss",
code: `$if[$getglobaluservar[kirby_boss]==Bitsy Woods]
$setglobaluservar[kirby_boss;Coin Defence API]
$setglobaluservar[kirby_stage;Exchange Road]
$elseif[$getglobaluservar[kirby_boss]==Coin Defence API]
$setglobaluservar[kirby_boss;Botty]
$setglobaluservar[kirby_stage;Encoded Ocean]
$endelseif
$elseif[$getglobaluservar[kirby_boss]==Botty]
$setglobaluservar[kirby_stage;Gigacoin Grounds]
$setglobaluservar[kirby_boss;Mecha Byte]
$endelseif
$elseif[$getglobaluservar[kirby_boss]==Mecha Byte]
$setglobaluservar[kirby_boss;DeDeDe Coin]
$setglobaluservar[kirby_stage;Coin Route]
$endelseif
$elseif[$getglobaluservar[kirby_boss]==DeDeDE Coin]
$setglobaluservar[kirby_boss;Star Coin]
$setglobaluservar[kirby_stage;The Final Bytes]
$setglobaluservar[message_after_boss;You have completed Kirby: The disappearance of the BittyCoin! Good job, you win 20.000 BittyCoins and a Star Coin BittyBadge!]
$endelseif
$endif`
})