module.exports.awaitedCommand = ({
	name: 'credits',
	code: ` $editMessage[$message[1];{title:Credits}{description:**Owner:**
\`$usertag[725463533814284419]\`
**This bot would not have been possible without our helper:**
\`$usertag[716168168422244382]\`
**testers:**
\`$usertag[632528935351222272], $usertag[255436078868070401]\`
**inspired certain commands and helped the bot grow:**
\`$usertag[728222970887274528]\`
**Creator of the duck API used in $getservervar[prefix]duck:**
\`$usertag[755601221582061680]\`
**Creator of the \(early access\) website:**
\`$usertag[566766267046821888]\`

**for being kind enough to use this bot**
\`$usertag\`
**Creator of the custom emojis:**
\`$usertag[638854865854136320]\`

<:back:806285459348783134> - back
}{color:$getServerVar[color]}{image:https://cdn.discordapp.com/attachments/760598463984566274/841648648613265408/image0.jpg}] `
});

