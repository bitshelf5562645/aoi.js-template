module.exports.awaitedCommand = ({
name: "cancel",
code: `$title[Alright!]
$description[You prestige has been cancelled!]
$color[$getservervar[color]]
$thumbnail[$useravatar[$clientID]]`
})
//it feels a little empty, lets add some images!