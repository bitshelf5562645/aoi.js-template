module.exports.awaitedCommand = ({
	name: 'image',
	code: `$editMessage[$message[1];{title:image commands help!} {description:\`$getservervar[prefix]av\`, get your user avatar or the avatar of the mentioned user, the user with the specified username or the user with the specified user ID.
\`$getservervar[prefix]fox\`, fetch a picture of a fox.
\`$getservervar[prefix]dog\`, fetch a picture of a dog.
\`$getservervar[prefix]cat\`, fetch a picture of a cat.
\`$getservervar[prefix]food\`, fetch a picture of food.
\`$getservervar[prefix]pikachu\`
get a pikachu image or gif.
\`$getservervar[prefix]birb\`
get an image of a birb.
\`$getservervar[prefix]hug\`
hug the mentioned user.
\`$getservervar[prefix]duck\`
get an image of a duck.
\`$getservervar[prefix]wink\`
wink at the mentioned user.
\`$getservervar[prefix]pat\`
pat the mentioned user.
\`$getservervar[prefix]redpanda / $getservervar[prefix]rp\`
get an image of a red panda.


<:back:806285459348783134> - back
  }{color:$getServerVar[color]}{image:https://cdn.discordapp.com/attachments/814114018301706330/814227361024442368/image0.gif}]`
});