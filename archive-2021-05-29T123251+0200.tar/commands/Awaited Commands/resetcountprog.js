module.exports.awaitedCommand = ({
name: "resetcountprog",
code: `
$setservervar[current_number;0]
$setservervar[last_counter;]`
})