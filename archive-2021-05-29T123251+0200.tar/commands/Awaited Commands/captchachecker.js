module.exports.awaitedCommand = ({
  name: "verify",
  code: `$title[tadaaa!]
  $description[You are now verified!]
  $color[$getservervar[color]]
  $giveRoles[$authorid;$getservervar[verified]]

  $onlyIf[$checkcontains[$message;$getuservar[captcha]]==true;{title:oopsie!} {description:You entered the wrong captcha code! Please try again!} {color:$getservervar[color]}]
$onlyif[$hasrole[$authorid;$getservervar[verified]]==false;{title:Oops!}{description:You are already verified!}{color:$getservervar[color]}]`
})