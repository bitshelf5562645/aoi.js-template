module.exports.awaitedCommand = ({
  name: "pantry",
  code: `$title[this is old!]
  $description[You searched in your pantry found some old $randomtext[chips;candy;soda] which you managed to sell for $numberseparator[$random[500;3000];,] BittyCoins!]
  $color[$getservervar[color]]
  $setglobaluservar[money;$sum[$getglobaluservar[money];$random[500;3000]]]
  $onlyIf[$checkContains[$getuservar[options];pantry]==true;]
  `
})

