module.exports.awaitedCommand = ({
	name: 'back',
	code: ` $editMessage[$message[1];{title:Help} {description:help paginator:
<:back:806285459348783134> - go back.
<:music_page:806284646912098345> - music help.
<:misc:806285458073583676> - misc help.
<:bittyconomy:806285460820983878> - Bittyconomy help.
<:fun:806285701104271390> - fun help.
<:credits:806285536925843556> - credits.
<:customizations:806285014651764756> - customization help.
<:image:808674981948948480> - image commands help.}{color:$getservervar[color]}{image:https://cdn.discordapp.com/attachments/814114018301706330/814227361024442368/image0.gif}] `
});

