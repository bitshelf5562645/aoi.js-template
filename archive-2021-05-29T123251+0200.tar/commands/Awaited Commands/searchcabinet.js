module.exports.awaitedCommand = ({
  name: "cabinet",
  code: `$title[Lookie Lookie!]
  $description[Sweeping away some cobwebs you found $numberseparator[$random[100;1000];,] BittyCoins!]
  $color[$getservervar[color]]
  $setglobaluservar[money;$sum[$getglobaluservar[money];$random[100;1000]]]
  $onlyIf[$checkContains[$getuservar[options];cabinet]==true;]
  `
})

