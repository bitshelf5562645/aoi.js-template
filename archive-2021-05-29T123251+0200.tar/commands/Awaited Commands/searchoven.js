module.exports.awaitedCommand = ({
  name: "oven",
  code: `$title[YOUCH!]
  $description[You searched through the oven and found $numberseparator[$random[500;3000];,] BittyCoins! How the heck did this money even get here?]
  $setglobaluservar[money;$sum[$getglobaluservar[money];$random[500;3000]]]
  $color[$getservervar[color]]
  
  $onlyIf[$checkContains[$getuservar[options];oven]==true;]`
})

