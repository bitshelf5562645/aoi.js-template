module.exports.awaitedCommand = ({
  name: "couch",
  code: `$title[this stinks!]
  $description[you looked in your couch and found an old sticky piece of candy, which a really shady kid bought from you for $numberseparator[$random[500;3000];,] BittyCoins!]
  $color[$getservervar[color]]
 $setglobaluservar[money;$sum[$getglobaluservar[money];$random[500;3000]]]
 $onlyIf[$checkContains[$getuservar[options];couch]==true;]
  `
})

