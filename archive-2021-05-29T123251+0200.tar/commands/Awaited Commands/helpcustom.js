module.exports.awaitedCommand = ({
	name: 'custom',
	code: ` $editMessage[$message[1];{title:customization help!} {description:\`$getservervar[prefix]setcolor\`
  Change the embed color of the embed messages for your server.
    
<:back:806285459348783134> - back
  }{color:$getServerVar[color]}{image:https://cdn.discordapp.com/attachments/760598463984566274/841648648613265408/image0.jpg}] `
});

