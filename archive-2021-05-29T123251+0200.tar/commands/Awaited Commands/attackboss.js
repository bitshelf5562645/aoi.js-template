module.exports.awaitedCommand = ({
name: "attackboss",
code: `
$if[$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber]]==1]
$title[POYO!]
$description[You attacked $getglobaluservar[kirby_boss], you landed a nice hit!
**attack** or **spit** your ability at it?

$addfield[$getglobaluservar[kirby_boss]'s health bar:;$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpstart]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp5]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp4]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp3]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp2]]<:hp_empty:845029100477480971>$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpend]];yes]
]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]]_hp1;<:hp_empty:845029100477480971>]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber];2]

$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$awaitmessages[$authorid;10m;attack,spit;attackboss;spit]

$elseif[$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber]]==2]
$title[POYO!]
$description[You attacked $getglobaluservar[kirby_boss], you landed a nice hit!
**attack** or **spit** your ability at it?

$addfield[$getglobaluservar[kirby_boss]'s health bar:;$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpstart]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp5]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp4]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp3]]<:hp_empty:845029100477480971>$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp1]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpend]];yes]
]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]]_hp2;<:hp_empty:845029100477480971>]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber];3]

$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$awaitmessages[$authorid;10m;attack,spit;attackboss;spit]
$endelseif

$elseif[$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber]]==3]
$title[POYO!]
$description[You attacked $getglobaluservar[kirby_boss], you landed a nice hit!
**attack** or **spit** your ability at it?

$addfield[$getglobaluservar[kirby_boss]'s health bar:;$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpstart]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp5]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp4]]<:hp_empty:845029100477480971>$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp2]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp1]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpend]];yes]
]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]]_hp3;<:hp_empty:845029100477480971>]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber];4]

$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$awaitmessages[$authorid;10m;attack,spit;attackboss;spit]
$endelseif

$elseif[$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber]]==4]
$title[POYO!]
$description[You attacked $getglobaluservar[kirby_boss], you landed a nice hit!
**attack** or **spit** your ability at it?

$addfield[$getglobaluservar[kirby_boss]'s health bar:;$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpstart]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp5]]<:hp_empty:845029100477480971>$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp3]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp2]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp1]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpend]];yes]
]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]]_hp4;<:hp_empty:845029100477480971>]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber];5]

$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$awaitmessages[$authorid;10m;attack,spit;attackboss;spit]
$endelseif

$elseif[$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpnumber]]==5]
$onlyif[4==5;{execute:setnextkirbyboss}]
$onlyif[4==6;{execute:prizeforwinningkirby}]
$title[POYO!]
$description[You attacked $getglobaluservar[kirby_boss], you landed a nice hit!
You defeated $getglobaluservar[kirby_boss]! You can now move on to the next world!


$addfield[$getglobaluservar[kirby_boss]'s health bar:;$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpstart]]<:hp_empty:845029100477480971>$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp4]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp3]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp2]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hp1]]$getglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]_hpend]];yes]
]
$setglobaluservar[$tolowercase[$replacetext[$getglobaluservar[kirby_boss]; ;_;-1]]_hp5;<:hp_empty:845029100477480971>]


$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$endelseif

$endif
`
})