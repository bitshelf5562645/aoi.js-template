module.exports.awaitedCommand = ({
name: "place5",
code: `$if[$authorid==$getmessagevar[starter]]
$editMessage[$message[1];{description:$getmessagevar[place1;$message[1]]|$getmessagevar[place2;$message[1]]|$getmessagevar[place3;$message[1]]
$getmessagevar[place4;$message[1]]|$getuservar[sign]|$getmessagevar[place6;$message[1]]
$getmessagevar[place7;$message[1]]|$getmessagevar[place8;$message[1]]|$getmessagevar[place9;$message[1]]}{color:$getservervar[color]}]
$setmessagevar[$commandname;$getuservar[sign;$authorid];$message[1]]

$elseif[$authorid==$getmessagevar[player]]
$editMessage[$message[1];{description:$getmessagevar[place1;$message[1]]|$getmessagevar[place2;$message[1]]|$getmessagevar[place3;$message[1]]
$getmessagevar[place4;$message[1]]|$getuservar[sign]|$getmessagevar[place6;$message[1]]
$getmessagevar[place7;$message[1]]|$getmessagevar[place8;$message[1]]|$getmessagevar[place9;$message[1]]}{color:$getservervar[color]}]
$setmessagevar[$commandname;$getuservar[sign;$authorid];$message[1]]
$endelseif

$elseif[$authorid!=$getmessagevar[player]]
<@$authorid> You are not a player of this match!
$endelseif

$elseif[$authorid!=$getmessagevar[starter]]
<@$authorid> You are not a player of this match!
$endelseif
$endif
$onlyif[$getmessagevar[$commandname;$message[1]]!=X;This spot is already filled!]
$onlyif[$getmessagevar[$commandname;$message[1]]!=O;This spot is already filled!]
$setmessagevar[whosturn;$authorid;$message[1]]

$onlyif[$getmessagevar[whosturn;$message[1]]!=$authorid;It's not your turn!]`
});