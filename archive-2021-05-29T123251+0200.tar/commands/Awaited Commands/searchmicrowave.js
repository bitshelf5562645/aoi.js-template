module.exports.awaitedCommand = ({
  name: "microwave",
  code: `$title[Dirty!]
  $description[You stick your hand in your old microwave, you found $random[100;1000] BittyCoins somehow.]
  $color[$getservervar[color]]
  $setglobaluservar[money;$sum[$getglobaluservar[money];$random[100;1000]]]
  $onlyIf[$checkContains[$getuservar[options];microwave]==true;]
  `
})

