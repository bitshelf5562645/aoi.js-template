module.exports.awaitedCommand = ({
name: "createfile",
code: `$usechannel[$getservervar[logschannel]] $createfile[$getchannelvar[ticket_convo];txt]
$wait[2s]`
})