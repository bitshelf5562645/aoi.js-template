module.exports.awaitedCommand = ({
  name: "sewer",
  code: `$title[Why just why?]
  $description[You took a dip in the sewers like a lunatic, you found nothing!]
  $color[$getservervar[color]]
  $onlyIf[$checkContains[$getuservar[options];sewer]==true;]
  `
});

