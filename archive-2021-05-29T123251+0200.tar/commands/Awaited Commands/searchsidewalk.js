module.exports.awaitedCommand = ({
  name: "sidewalk",
  code: `$title[sidewalk!]
  $description[You looked if you could find anything on the sidewalk and found $numberseparator[$random[300;3000];,]]
  $color[$getservervar[color]]
  $setglobaluservar[money;$sum[$getglobaluservar[money];$random[300;3000]]]
  $onlyIf[$checkContains[$getuservar[options];sidewalk]==true;]
  `
})