module.exports.awaitedCommand = ({
	name: 'fun',
	code: ` $editMessage[$message[1];{title:Fun help!} {description:Chatbot function, disabled by default, staff can enable it, chatbot help is in misc help!
\`$getservervar[prefix]meme\`, fetch a random meme or funny image from Reddit.
\`$getservervar[prefix]poll\`, start a poll.
\`$getservervar[prefix]gay\`, overlay a rainbow over the mentioned user.
\`$getservervar[prefix]invert\`, invert the colors of the mentioned user's avatar.
\`$getservervar[prefix]say\`
make the bot say what you specified.
\`$getservervar[prefix]wasted\`, overlays a wasted image over the mentioned user's avatar.
\`$getservervar[prefix]tts\`, text to speach the specified message in a voice channel (you have to be in one.)
\`$getservervar[prefix]clap,\`, put a clap emoji between every word of your message.
\`$getservervar[prefix]pp\`, very accurate pp size machine.
\`$getservervar[prefix]sbtc / $getservervar[prefix]spongebobtimecard\`, show a spongebob card like the 2000 years later one with your specified message.
\`$getservervar[prefix]burn\`, burns your avatar or the mentioned user's avatar, if you don't specify a value the standard value will be 1.
\`$getservervar[prefix]circle\`, turns your avatar or the mentioned user's avatar into a circle.
\`$getservervar[prefix]triggered\`, renders a gif of your avatar or the mentioned user's avatar being triggered.
\`$getservervar[prefix]bwrap\`, get an embed of some bubblewrap.
\`$getservervar[prefix]hack\`, hack the mentioned user, **very real no clickbait!!!!**.
\`$getservervar[prefix]jail\` jail your avatar or the mentioned user's avatar, if you say yes after the mention the image will be greyscaled, saying no or nothing after the mention will give it the normal colors.
\`$getservervar[prefix]magik\`, distort the mentioned user's avatar.
\`$getservervar[prefix]sepia\`, render a sepia filter over your avatar or the mentioned user's avatar.
\`$getservervar[prefix]stickbug\`, get a stickbug video of your avatar or the mentioned user's avatar.
\`$getservervar[prefix]separate / $getservervar[prefix]sep\`, seperate your message with a lot of spaces.
\`$getservervar[prefix]ship\`, ship someone with someone.
\`$getservervar[prefix]owoify\`, owoifies your message OwO.
\`$getservervar[prefix]uwuify\`,UwUifies your message UwU.
\`$getservervar[prefix]8ball\`, ask the 8 ball something.
\`$getservervar[prefix]mocktext\`, MaKE yOuR MesSaGE lIkE ThiS.


<:back:806285459348783134> - back
  }{color:$getServerVar[color]}{image:https://cdn.discordapp.com/attachments/760598463984566274/841648648613265408/image0.jpg}] `
});

