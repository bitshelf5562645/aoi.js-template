module.exports.botJoinCommand = ({
channel: "819628020901871616",
code: `

$if[$getvar[goal]>=$servercount]
$editmessage[819628104972501042;current server count: $servercount. 
Goal: $getvar[goal]]

$elseif[$getvar[goal]<=$servercount]
$setvar[goal;$sum[$getvar[goal];5]]
$editmessage[819628104972501042;current server count: $servercount. 
Goal: $sum[$getvar[goal];5]]
$endelseif
$endif`
})