module.exports.botLeaveCommand = ({
	channel: "803648702060953630",
	code: `$description[I have left $serverName]
  $color[RED]
`
})