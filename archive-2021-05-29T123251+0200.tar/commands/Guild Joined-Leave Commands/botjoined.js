module.exports.botJoinCommand = ({
	channel: "803648702060953630",
	code: `$description[I have joined $serverName, it has $numberseparator[$memberscount;,] members]
  $color[GREEN]


`
});