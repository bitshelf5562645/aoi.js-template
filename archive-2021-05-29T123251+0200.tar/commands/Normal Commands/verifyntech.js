module.exports.command = ({
name: "verify",
code: `$title[Tadaaa!]
$description[You have been verified, have fun in $servername!]
$giverole[$authorid;$findrole[𒀖⋄ Members]]
$color[GREEN]
$onlyforservers[791713097462972457;]
$onlyforchannels[846762687261310986;]
$deletecommand
$dm
$suppresserrors[An error occured, please try again later!]
`
})
