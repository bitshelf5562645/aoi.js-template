module.exports.command = ({
  name: "policy",
  description: `This command outputs the bots privacy policy`,
  code: `$title[Privacy Policy]
$description[**What data you collect?**

*The data we collect is your User ID and/or your username!.*

**How do you use our data?**

*User ID* - \`Used to store how much money you have, if the bot does not have access to your ID, then you'll have 0$ in every server as the bot won't know if you've worked or not.\`

**Where does my data go?**

*The data gets stored in dbd.db servers, aka dbd.js's database, however me nor the Dev Team have access to this data, only the people with access to the database servers!*

**Do you share any of our data with anyone?**

*I do not share any personal data with any third party services, the dev team does not have access to edit the codes or edit the actual bot. I, as a developer also do not have access to the data!*

**How can I contact the developer?**

*You can contact me by joining my support server (b!support) or sending me a friend request at $username[725463533814284419]#$discriminator[725463533814284419].*

**How can I request my data to be removed from the bot?**

*You can remove your data by running \`b!reset\` and let the bot remove your data from the dbd.db database!*]

$footer[requested by $usertag;$authoravatar]
$color[F1C40F]
$addtimestamp`
})