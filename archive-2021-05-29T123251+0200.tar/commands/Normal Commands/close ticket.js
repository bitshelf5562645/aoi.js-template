module.exports.command = ({
name: "close",
code: `
$dm[$getchannelvar[ticket_author]]
You have closed your ticket, here is your transcript $createfile[$usertag[$clientid]: Welcome to your ticket $usertag[$getchannelvar[ticket_author]], support will show up soon!
In the meantime please tell us about the problem you seem to be having so we can help you in the best way we can.
$replacetext[$getchannelvar[ticket_convo];$usertag[$getchannelvar[ticket_author]];;-1];txt]
$channelsendmessage[$getservervar[logschannel];{title:new ticket transcript!}{description:This was $usertag[$getchannelvar[ticket_author]]'s ticket}{color:$getservervar[color]}{execute:createfile}]

$closeticket

`
})