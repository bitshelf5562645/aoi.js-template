module.exports.command = ({
name: "new",
code: `$title[Done!]
$description[Your ticket has been created, you have been pinged, you should see it in your mentions.]
$color[$getservervar[color]]
$footer[Ticket created by $usertag;$authoravatar]
$addtimestamp

$setchannelvar[ticket_author;$authorID;$splitText[1]] $textsplit[$newTicket[ticket-$sum[$getservervar[number_of_tickets];1];<@$authorid>{title:Hi there!}{description:Welcome to your ticket $usertag, support will show up soon!
In the meantime please tell us about the problem you seem to be having so we can help you in the best way we can.}{color:$getservervar[color]};;yes;I have failed to open a ticket for you, I might be missing permission or there are too many channels in the server.]]
$setglobaluservar[ticket_author;$authorid]
$setservervar[number_of_tickets;$sum[$getservervar[number_of_tickets];1]]`
})