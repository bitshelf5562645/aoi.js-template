module.exports.command = ({
name: "servers",
description: `This command prints the amount of servers I'm in and how many total users I have.`,
code: `
$title[Servers]
$color[$getserverVar[color]]
$thumbnail[https://cdn.discordapp.com/emojis/795048212406206476.png?size=2048]
$description[I am in $serverCount servers and have $numberSeparator[$allMembersCount;,] total users.
Each server has an average of $numberseparator[$truncate[$divide[$allmemberscount;$servercount]];,] members.]
$footer[Requested by $username[$authorID]#$discriminator[$authorID];$authorAvatar]
$addTimestamp
$author[thanks for the support!;https://cdn.discordapp.com/emojis/787801561413451786.gif]`

})