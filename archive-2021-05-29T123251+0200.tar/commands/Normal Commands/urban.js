module.exports.command = ({
name: "urban",
code: `Disclaimer: Bittyconomy will not be held responsible for any unwanted or offensive definitions or words, this command is NSFW for a reason!
$title[Urban]
$description[
$addfield[URL to page;[Definition of $message]($jsonrequest[http://urbanscraper.herokuapp.com/define/$replacetext[$message; ;%20;-1];url]);yes]
$addfield[Example;$replacetext[$jsonrequest[http://urbanscraper.herokuapp.com/define/$replacetext[$message; ;%20;-1];example];$message;__$message__;-1];no]
$addfield[Definition;$jsonrequest[http://urbanscraper.herokuapp.com/define/$replacetext[$message; ;%20;-1];definition];yes]
$addfield[Term;$tolocaleuppercase[$message];no]]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$argscheck[1>;Please provide a word!]
$onlynsfw[This command is only for NSFW channels due to the nature of Urban Dictionary.]
`
})