module.exports.command = ({
  name: "setcolor",
  code: `$title[color set!]
  $description[I have set the color in $servername to $touppercase[$message], this message has your chosen embed color to preview what you chose!]
  $footer[requested by $usertag[$authorID];$authorAvatar]
  $addTimeStamp
  $setServerVar[color;$touppercase[$message]]
  $color[$touppercase[$message]]
  
  $suppressErrors[This is not a valid customizable option]
  $argsCheck[1;Usage: $getservervar[prefix]setcolor <hex color code or color name like red, not all names work, all hex codes DO work>]
  $onlyPerms[manageserver;only staff with manage server permissions can use this!]`
  
})