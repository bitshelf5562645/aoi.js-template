module.exports.command = ({
name: "$alwaysExecute",
code: `$if[$hasperms[$clientid;managenicknames]==true]
$description[$usertag welcome back! I have removed your AFK! Have fun chatting!]
$color[$getservervar[color]]
$author[Welcome back!;$servericon]
$setuservar[afk;false]
$changenickname[$authorid;$replacetext[$nickname;\[AFK\];;-1]]
$onlyif[$getuservar[afk]==true;]
$onlyif[$checkcontains[$message;$getservervar[prefix]afk]==false;]

$elseif[$hasperms[$authorid;managenicknames]==false]
$description[$usertag welcome back! I have removed your AFK! Have fun chatting!]
$color[$getservervar[color]]
$author[Welcome back!;$servericon]
$setuservar[afk;false]
$onlyif[$getuservar[afk]==true;]
$onlyif[$checkcontains[$message;$getservervar[prefix]afk]==false;]
$endelseif

$elseif[$authorid==$serverowner]
$description[$usertag welcome back! I have removed your AFK! Have fun chatting!]
$color[$getservervar[color]]
$author[Welcome back!;$servericon]
$setuservar[afk;false]
$onlyif[$getuservar[afk]==true;]
$endelseif

$endif
$onlyif[$checkcontains[$message[1];afk]==false;]
$suppresserrors
`
})