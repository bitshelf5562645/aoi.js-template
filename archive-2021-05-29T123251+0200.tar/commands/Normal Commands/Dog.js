module.exports.command = ({
  name: "doggo",
  description: `This command sends a random picture of a dog`,
  aliases: ["dog"],
  code: `$image[$jsonrequest[https://random.dog/woof.json;url;an error occurred, please try again later.]]
  $title[Doggo!]
  $description[Look at this lil' pupper!]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $color[$getservervar[color]]
  $addtimestamp`
})