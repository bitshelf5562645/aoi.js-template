module.exports.command = ({
name: "update",
aliases: ["ud"],
code: `$reboot $onlyForIDs[$botownerid;Devs only!]`

})