module.exports.command = ({
name: "owoify",
code: `$title[OwOify]
$description[$addfield[Output;$jsonrequest[https://api.jastinch.xyz/owoify?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&text=$replacetext[$message; ;%20;-1];res];no]
$addfield[Input;$message;no]]
$color[$getservervar[color]]
`
})