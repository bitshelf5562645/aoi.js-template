module.exports.command = ({
  name: "spongebobtimecard",
  aliases: ["sbtc"],
  code: `$title[2000 years later]
  $image[https://api.devs-hub.xyz/spongebob-timecard?text=$replacetext[$message; ;%20;-1]]
  $color[$getservervar[color]]
  $footer[requested by $usertag;$authoravatar]
  $addtimestamp
  $argscheck[1>;please choose something for the image to say!]`
})