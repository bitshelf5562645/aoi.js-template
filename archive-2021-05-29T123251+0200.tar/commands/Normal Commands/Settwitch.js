module.exports.command = ({
name: "settwitch",
code: `$title[Twitch Linked!]
$description[I have set your Twitch bio link to \`$message[1]\`]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
$addtimestamp
$setglobaluservar[biotwitch;$message[1]]
$onlyifmessagecontains[$message[1];https;twitch]`
})