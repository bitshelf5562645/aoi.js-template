module.exports.command = ({
name: "translate",
code: `$title[Translator]
$addfield[Output;$jsonrequest[https://api.jastinch.xyz/translate?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&to=en&text=$replacetext[$message; ;%20;-1];res];no]
$addfield[Input;$message;no]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp`
})