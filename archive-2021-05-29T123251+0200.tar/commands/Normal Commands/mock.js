module.exports.command = ({
name: "mock",
code: `$jsonrequest[https://api.pslimy.ga/mocktext?text=$message;result] $deletecommand`
})