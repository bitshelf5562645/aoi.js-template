module.exports.command = ({
  name: "birb",
  description: `This command sends a random picture of a bird.`,
  code: `$title[Birb!]
  $description[look at this lil' birb]
  $image[$jsonrequest[https://some-random-api.ml/img/birb;link;An error occurred, please try again later!]]
  $color[$getservervar[color]]
  $footer[requested by $usertag[$authorID];$authoravatar]
  $addtimestamp`
});