module.exports.command = ({
name: "eval",
aliases: "ev",
code: `$eval[$message]
$onlyForIDs[$botownerid;:star: You tried]`
});