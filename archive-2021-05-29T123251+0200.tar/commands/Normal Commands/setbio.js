module.exports.command = ({
name: "setbio",
code: `$title[Success!]
$description[I have set your bio to \`$message\`, dont forget you can use $getservervar[prefix]settwitch to set your twitch account and $getservervar[prefix]setyoutube to set your youtube account]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$color[$getservervar[color]]
$setglobaluservar[biomessage;$message]`
})