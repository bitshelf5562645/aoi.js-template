module.exports.command = ({
name: "$alwaysExecute",
code: `$if[$getchannelvar[ticket_convo]==This is the start of the ticket.]
$setchannelvar[ticket_convo;$usertag: $message]

$else
$setchannelvar[ticket_convo;$getchannelvar[ticket_convo]

$usertag: $message]

$endif

$onlyif[$isticket==true;]
`
})