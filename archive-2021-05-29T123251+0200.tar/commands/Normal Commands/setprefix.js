module.exports.command = ({
  name: "setprefix",
  aliases: ["sp"],
  code: `
  $title[Setting prefix!]
  $description[You have now set the prefix for bittyconomy in. $serverName[$guildID] to $message]
  $footer[Requested by $username#$discriminator[$authorID]]
  $color[$getServerVar[color]]
  $setServerVar[prefix;$message]
  $onlyif[$charcount[$message]<=4;The prefix can not be more than 4 characters!]
  $onlyPerms[manageserver;Only staff with manage server permissions can run this command!]`
});