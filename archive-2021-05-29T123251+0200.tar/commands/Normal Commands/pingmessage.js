module.exports.command = ({
  name: "$alwaysExecute",
  code: `$if[$checkContains[$message;<@760515811000582165>;<@!760515811000582165>]==true]
 $title[Hi there!]
$description[Hello $usertag! I'm Bittyconomy, thanks for adding me to your server $servername, use B!help to get started!]
$footer[requested by $usertag;$authoravatar] 
$color[$getservervar[color]]
$addtimestamp
  $endif`
})