module.exports.command = ({
name: "setyoutube",
aliases: "setyt",
code: `$title[Youtube Linked!]
$description[I have set your Youtube bio link to \`$message[1]\`]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
$addtimestamp
$setglobaluservar[bioyt;$message[1]]
$onlyifmessagecontains[$message[1];https;youtube]
$onlyif[$checkcontains[$message[1];watch]==false;]`
})