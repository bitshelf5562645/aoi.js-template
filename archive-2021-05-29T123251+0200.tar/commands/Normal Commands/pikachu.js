module.exports.command = ({
  name: "pikachu",
  description: `This command sends a random attachment of a pikachu.`,
  code: `$title[Pikachu!]
  $image[$jsonrequest[https://some-random-api.ml/img/pikachu;link;An error occurred, please try again later!]]
  $color[$getservervar[color]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp`
})