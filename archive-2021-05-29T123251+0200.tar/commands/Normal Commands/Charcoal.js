module.exports.command = ({
  name: "charcoal",
  code: `$djseval[const Discord = require("discord.js");
const client = new Discord.Client()
const gm = require("gm")
        let img = message.mentions.members.size !== 0 ? message.mentions.users.first().displayAvatarURL({ format: "png" }) : message.attachments.size !== 0 ? message.attachments.first().url : message.author.displayAvatarURL({ format: "png" })    gm(img).charcoal(1).then(image => {
        let attachment = new Discord.MessageAttachment(image, "charcoal.png")
        return message.channel.send(attachment)
})
  ]`
})