module.exports.command = ({
  name: "userinfo",
  
  description: `This command prints the user info of the mentioned user, if no user is specified it will print your user info.`,
  code: `$title[Who is that?]
  $description[$addField[Permissions;\`$userperms[$findUser[$message];
  ** **]\`;no]
  
  $addField[:man_technologist:| Roles:;$userroles[$findUser[$message];mentions];no]

$addField[:busts_in_silhouette:| Joined server on:;\`$memberjoineddate[$finduser[$message];date]\`;yes]

$addField[:busts_in_silhouette:| Has been in this server for:;\`$memberjoineddate[$finduser[$message];time]\`;yes]

$addField[** **;** **;yes]

$addField[:hourglass:| Account created on:;\`$creationdate[$finduser[$message];date]\`;yes]
  
$addField[:hourglass_flowing_sand:| Account age:;\`$creationdate[$finduser[$message];time]\`;yes]
  
$addField[:hash:| User tag:;\`$usertag[$finduser[$message]]\`;no]]
$footer[requested by $usertag[$authorid];$authoravatar]
$addtimestamp
$thumbnail[$useravatar[$finduser[$message]]]
$color[$getservervar[color]]`
})

