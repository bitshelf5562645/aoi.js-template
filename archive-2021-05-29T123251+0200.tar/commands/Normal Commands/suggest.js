module.exports.command = ({
  name: "suggest",
code: `$color[$getservervar[color]]
$title[$username[$authorID]#$discriminator[$authorID] suggested something!]
<@&775828181877391361>
$description[\`$message\`

🔴 = won’t get added.
🟢 = put in queue.
✅ = added.]
$deletecommand
$footer[Requested by $username[$authorID]#$discriminator[$authorID];$authorAvatar]
$addTimestamp
$addReactions[<a:vote_no:765265576272461844>;<a:vote_yes:765265518658977854>]
$usechannel[776807131764359179]
$globalCooldown[10m;You need to wait %time% to use this again!]
$argscheck[1>;Please suggest something]`
})