module.exports.command = ({
  name: "duck",
  description: `This command sends a random picture of a duck, this command might lag a bit`,
  code: `$title[Quack]
  $description[look at this lil' quacker!]
  $image[$jsonrequest[http://bald-utopian-office.glitch.me/duck;duck]]
  $color[$getservervar[color]]
  $footer[requested by $usertag;$authoravatar]`
})