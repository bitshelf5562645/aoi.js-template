module.exports.command = ({
name: "botinfo",
code: `$title[Bot info!]
$description[Some info about Bittyconomy!
$addfield[Packages;\`\`\`AOI.JS version $packageversion
Database version $djsEval[require('dbdjs.db').version;yes]\`\`\`;no]
$addfield[Uptime;\`\`\`$uptime\`\`\`;no]
$addfield[Users;\`\`\`$numberseparator[$allmemberscount;,]\`\`\`;no]
$addfield[Servers;\`\`\`$servercount\`\`\`;no]
$addfield[Command count;\`\`\`$commandscount\`\`\`;no]
$addfield[Bot Ping;\`\`\`$botpingms\`\`\`;no]
$addfield[Bot Ping \(seconds\);\`\`\`$divide[$botping;1000] seconds\`\`\`;no]
$addfield[Websocket Ping \(seconds\);\`\`\`$divide[$ping;1000] seconds\`\`\`;no]
$addfield[Websocket Ping;\`\`\`$pingms\`\`\`;no]
$addfield[CPU Usage;\`\`\`$cpu%\`\`\`;no]
$addfield[RAM Usage;\`\`\`$ramMB\`\`\`;no]
$addfield[Bot age;\`\`\`$creationdate[$clientid;time]\`\`\`;no]
$addfield[Owner;\`\`\`$usertag[$botownerid]\`\`\`;no]]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp`
})