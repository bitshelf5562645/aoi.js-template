module.exports.command = ({
  name: "pat",
  description: `Pat the mentioned user, this command sends am attachment of it.`,
  code: `$title[$username patted $username[$finduser[$message]]!]
  $image[$jsonrequest[https://some-random-api.ml/animu/pat;link;An error occurred, please try again later!]]
  $color[$getservervar[color]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp
  $argscheck[1>;please mention someone or use their username!]
  `
})