module.exports.command = ({
name: "invite",
description: `This command sends as inite for the bot this includes a hyperlink and a normal link marked as spoilers for if you want to share the link with a friend.`,
  aliases: ["inv", "i"],
  code: `$title[Invite me!]
$description[To invite me to your server [click here!](https://discord.com/oauth2/authorize?client_id=760515811000582165&scope=bot+applications.commands&permissions=1278602609)]
Here is the link fully for if you want to copy it and share it with a friend:
https://discord.com/oauth2/authorize?client_id=760515811000582165&scope=bot+applications.commands&permissions=1278602609
$color[$getServerVar[color]]
$thumbnail[https://cdn.discordapp.com/avatars/760515811000582165/6d0b7994ffa7fd5038dd3dd6976d4e0c.webp?size=2048?size=2048]
$footer[requested by $usertag[$authorID];$authorAvatar]
$addTimestamp`
})