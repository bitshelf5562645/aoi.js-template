module.exports.command = ({
name: "afk",
code: `
$if[$hasperms[$clientid;managenicknames]==true]
$title[Done!]
$description[You are now afk with the reason: \`$message\`
I have also changed your nickname!]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$setuservar[afk_message;$message]
$setuservar[afk;true]
$changenickname[$authorid;\[AFK\] $nickname]

$elseif[$hasperms[$clientid;managenicknames]==false]

$title[Done!]
$description[You are now afk with the reason: \`$message\`
However I was unable to change your nickname because I am missing the permission to do so.]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$setuservar[afk_message;$message]
$setuservar[afk;true]
$endelseif

$elseif[$authorid==$serverowner]

$title[Done!]
$description[You are now afk with the reason: \`$message\`
However I was unable to change your nickname because you're the server owner.]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$setuservar[afk_message;$message]
$setuservar[afk;true]
$endelseif

$endif

$suppresserrors
$onlyif[$getuservar[afk]==false;]`
})