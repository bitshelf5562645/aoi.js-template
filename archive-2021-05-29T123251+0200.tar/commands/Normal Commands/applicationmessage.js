module.exports.command = ({
name: "$alwaysExecute",
code: `$title[Hi there $usertag!]
$description[Hello $usertag, please read this message:
This response was triggered because your messages contained "staff" and "apply", unfortunately staff applications are not currently open, please wait until they open.
Thanks for your interest in this community!]
$color[ff0000]
$footer[ ]
$addtimestamp
$onlyforservers[775657653602877460;]
$onlyifmessagecontains[$message;staff;apply;]`
})