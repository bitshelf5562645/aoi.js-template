module.exports.command = ({
  name: "panda",
  description: `This command sends a random picture of a panda.`,
  code: `$title[Look at this big guy!]
  $description[panda go brrr]
  $image[$jsonrequest[https://some-random-api.ml/img/panda;link;An error occurred, please try again later!]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp
  $color[$getservervar[color]]`
})

//https://some-random-api.ml/img/panda