module.exports.command = ({
  name: "commandinfo",
  description: `This command prints the info and purpose of your specified command.`,
  code: `$title[commandinfo!]
  $description[**Info about $message:**
  
\`$commandinfo[$message;description]\`]
$color[$getservervar[color]]`
})