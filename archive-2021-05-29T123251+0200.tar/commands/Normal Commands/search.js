module.exports.command = ({
  name: "search",
  code: `$title[searching!]
  $description[Please pick where you wanna search: $randomText[fridge;microwave], $randomtext[pantry;cabinet], $randomText[oven;sidewalk;toilet] or the $randomText[couch;sewer].]
  $footer[requested by $usertag;$authoravatar]
  $setuservar[options;$randomtext[fridge;microwave] $randomtext[pantry;cabinet] $randomtext[oven;sidewalk;toilet] $randomtext[couch;sewer]]
  $color[$getservervar[color]]
  $awaitmessages[$authorid;5m;fridge,pantry,oven,couch,microwave,cabinet,sidewalk,sewer,toilet;fridge,pantry,oven,couch,microwave,cabinet,sidewalk,sewer,toilet]
  $globalcooldown[5m;Slow it down, please wait %time% until using this again!]`
});