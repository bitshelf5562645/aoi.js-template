module.exports.command = ({
  name: "food",
  description: `This commands sends a random picture of a food dish.`,
  code: `$image[$jsonrequest[https://foodish-api.herokuapp.com/api/;image;an error occurred. please try again later!]]
  $description[** **]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp
  $color[$getservervar[color]]`
})