module.exports.command = ({
  name: "hug",
  description: `Hug the mentioned user, this command will send an attachment of it.`,
  code: `$title[$username hugged $username[$finduser[$message]]!]
  $image[$jsonrequest[https://some-random-api.ml/animu/hug;link;An error occurred, please try again later!]]
  $color[$getservervar[color]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp
  $argscheck[1>;please mention someone or use their username!]
  `
})