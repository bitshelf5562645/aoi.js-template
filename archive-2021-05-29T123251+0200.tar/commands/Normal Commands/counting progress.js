module.exports.command = ({
name: "$alwaysExecute",
code: `$if[$nomentionmessage[1]==$sum[$getservervar[current_number];1]]
$addMessageReactions[$channelid;$messageid;<a:avoteYes:777975349135802368>]
$setservervar[current_number;$sum[$getservervar[current_number];1]]
$setservervar[last_counter;$authorid]

$else
$author[Counting in $servername;$servericon]
$title[Oops!]
$description[That was the wrong number! Counting progress has been reset!]
$footer[Mistake made by $usertag;$authoravatar]
$color[RED]

$setservervar[current_number;0]
$endif

$onlyif[$authorid!=$getservervar[last_counter];{title:uh oh!}{description:$usertag ruined the count by attempting to count twice in a row! The count has been reset!}{color:RED}{author:Counting in $servername:$servericon}{footer:Mistake made by $usertag:$authoravatar}{execute:resetcountprog}]
$onlyif[$checkcontains[$nomentionmessage[1];q;w;e;r;t;y;u;i;o;p;a;s;d;f;g;h;j;k;l;z;x;c;v;b;n;m]==false;]
$onlyif[$channelid==$getservervar[counting_channel];]
`
})