module.exports.command = {
	name: 'cat',
  description: `This command sens a random picture of a cat`,
	code: `$image[$jsonRequest[https://aws.random.cat/meow;file;an error occurred, try again later]]
  $title[Lil' kitty!]
  $description[Look at this cute lil' kitty!]
  $footer[requested by $usertag[$authorID];$authoravatar]
  $addtimestamp
  $color[$getservervar[color]]`
};
