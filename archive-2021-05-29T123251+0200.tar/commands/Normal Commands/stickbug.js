module.exports.command = ({
  name: "stickbug",
  description: `Get stickbugged, lol.`,
  code: `$djsEval[
			const Caxinha = require("caxinha");
			const Discord = require("discord.js");
            message.reply("Rendering image...")
            message.channel.startTyping();
            let image = message.mentions.users.first() || message.author;

            Caxinha.canvas.stickbug(image.displayAvatarURL({ format: "png" })).then(generated => {
        		let img = new Discord.MessageAttachment(generated, "stickbug.mp4");
                message.channel.stopTyping();
                message.channel.send(img);
			}).catch(() => {
            	message.channel.stopTyping();
            	return message.reply("I was unable to find lines in " + image === message.mentions.users.first().displayAvatarURL({ format: "png" }) ? "the mention user's" : "your" + "avatar.")
        	})
]`
})