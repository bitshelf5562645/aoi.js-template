module.exports.command = ({
name: "serverinfo",
code: `$title[Server info]
$description[$addfield[roles:;$guildroles[mention]]
$addfield[** **;** **;yes]
$addfield[server created on:;$creationDate[$guildID];yes]
$addfield[server age:;$creationDate[$guildID;time];yes]
$addfield[owner:;<@$ownerid>;yes]
$addfield[Rolecount:;$rolecount;yes]
$addfield[channels:;$channelcount;yes]]
$color[$getservervar[color]]
$image[$servericon]`
});