module.exports.command = ({
name: "counting",
aliases: "bind",
code: `$author[Counting has started in $servername;$servericon]
$title[Done!]
$description[I have bind to this channel and counting has started, the first number is 1]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]

$setservervar[counting_channel;$channelid]
`
})