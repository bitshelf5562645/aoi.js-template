module.exports.command = ({
  name: "wink",
  description: `Wink at the mentioned user, this command sends an attachment of it.`,
  code: `$title[$username winked at $username[$finduser[$message]]!]
  $image[$jsonrequest[https://some-random-api.ml/animu/wink;link;An error occurred, please try again later!]]
  $color[$getservervar[color]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp
  $argscheck[1>;please mention someone or use their username!]`
})