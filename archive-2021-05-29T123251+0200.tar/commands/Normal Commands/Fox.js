module.exports.command = ({
  name: "fox",
  description: `This command sends a random picture of a fox`,
  code: `$image[$jsonRequest[https://randomfox.ca/floof/;image;an error occurred, try again later]]
  $title[Fox!]
  $description[Look at this cute lil' guy!]
  $footer[requested by $usertag[$authorID];$authoravatar]
  $addtimestamp
  $color[$getservervar[color]]`
});