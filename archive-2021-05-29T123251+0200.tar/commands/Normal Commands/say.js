module.exports.command = ({
  name: "say",
  code: `$deletecommand
$message
$suppressErrors[]
$onlyIf[$checkContains[$message;@here;@everyone;@]==false;You can't mention anyone in the say command to avoid raiders exploiting this command, sorry!]
$argsCheck[>1;Write something to say!]`
});