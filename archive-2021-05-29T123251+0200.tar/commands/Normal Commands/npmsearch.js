module.exports.command = ({
name: "npmsearch",
aliases: "npm",
code: `$title[NPM search]
$description[$addfield[Previous Version;$jsonrequest[https://api.jastinch.xyz/npm?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&search=$message;lastVersion]]
$addfield[Keywords;$replacetext[$jsonrequest[https://api.jastinch.xyz/npm?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&search=$message;keywords];,;, ;-1]]
$addfield[URL;$jsonrequest[https://api.jastinch.xyz/npm?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&search=$message;url]]
$addfield[Description;$jsonrequest[https://api.jastinch.xyz/npm?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&search=$message;description]]
$addfield[Name;$jsonrequest[https://api.jastinch.xyz/npm?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&search=$message;name]]
$addfield[Developer;$jsonrequest[https://api.jastinch.xyz/npm?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&search=$message;publisher]]]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
$addtimestamp
$suppresserrors[Package not found!]`
})