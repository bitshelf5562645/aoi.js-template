module.exports.command = ({
  name: "botlists",
  aliases: ["bl", "vote"],
  description: `This command prints the bot lists I am in including hyperlinks to my page in these lists.`,
  code: `$color[$getservervar[color]]
$title[The bot lists you can currently find me on!]
$description[[**Discord Bot List EU**](https://discord-botlist.eu/bots/760515811000582165)

[**Blist**](https://blist.xyz/bot/760515811000582165/)

[**Space Bot List**](https://space-bot-list.xyz/bots/760515811000582165)

[**Astro Bot List**](https://botlists.com/bot/760515811000582165)

[**Top.gg**](https://top.gg/bot/760515811000582165)

[**Discord Extreme List**](https://discordextremelist.xyz/en-US/bots/760515811000582165)

[**Bots For Discord**](https://botsfordiscord.com/bot/760515811000582165)

[**Botlist Space**](https://botlist.space/bot/760515811000582165)]
$footer[Requested by $usertag[$authorID];$authoravatar]
$addTimestamp`
})