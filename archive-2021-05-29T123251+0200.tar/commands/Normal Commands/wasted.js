module.exports.command = ({
  name: "wasted",
  code: `$title[wasted!]
  $image[$replacetext[https://some-random-api.ml/canvas/wasted?avatar=$useravatar[$finduser[$message]];webp;png;-1]]
  $color[$getservervar[color]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp`
})