module.exports.command = ({
  name: "chatbot",
  aliases: ["cb"],
  code: `$setServerVar[chatChannel;$mentionedChannels[1;yes]]
  $setServerVar[chatbot;on]

$color[$getServerVar[color]]
$description[Chatbot is now on, to make it work in a specific channel use \`$getservervar[prefix]cb on #channel mention\` and to stop the chatbot use \`$getservervar[prefix]cb off\`!]
$footer[Requested by $userTag[$authorID];$userAvatar[$authorID]]

$onlyPerms[managechannels;Only staff with manage channels permissions can use this]
$onlyIf[$checkContains[$message;on]==true;]`
});