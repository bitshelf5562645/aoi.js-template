module.exports.command = ({
name: "bio",
aliases: "getbio",
code: `$title[$usertag[$finduser[$message]]'s bio]
$description[\`\`\`$getglobaluservar[biomessage;$finduser[$message]]\`\`\`
$addfield[**Twitch:**;$getglobaluservar[biotwitch;$finduser[$message]];no]
$addfield[**Youtube:**;$getglobaluservar[bioyt;$finduser[$message]];yes]]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
`
})