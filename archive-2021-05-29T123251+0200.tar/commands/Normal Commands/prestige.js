module.exports.command = ({
name: "prestige",
code: `$title[Prestige]
$description[You are about to prestige, you will lose all money you have, including deposited money, you will also lose all bank upgrades, if you say "yes" this will be done and you will receive a money boost of $math[$getglobaluservar[prestige_multiplier]+1], are you sure you want to proceed, you can also say "cancel" to prevent prestiging, this command will stop awaiting your reply after five minutes.]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
$addtimestamp
$thumbnail[$useravatar[$clientID]]
$awaitmessages[$authorid;5m;yes,cancel;yes,cancel]
`
})
//We're gonna change how it works, we're gonna make it so you have to confirm if you want it

//this info will be in the awaited command: You used a prestige, all your wallet money, deposited money and all bank upgrades have been sacrificed for this, you now have a $getglobaluservar[prestige_multiplier] multiplier

//now to make this command await messages.

//part 3 coming soon