module.exports.command = ({
  name: "gay",
  code: `$title[gay!]
  $image[$replacetext[https://some-random-api.ml/canvas/gay?avatar=$useravatar[$finduser[$message]];webp;png;-1]]
  $color[$getservervar[color]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp
  `
})