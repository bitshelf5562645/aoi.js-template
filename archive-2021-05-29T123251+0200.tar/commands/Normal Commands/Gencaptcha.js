module.exports.command = ({
  name: "generatecaptcha",
  description: `This command generates a captcha for you so you can use $getservervar[prefix]captcha and verify by sending the code you see.`,
  aliases: ["gencaptcha", "gc"],
  code: `$setUserVar[captcha;$replacetext[$replacetext[$randomString[5];l;1;-1];I;6;-1]]
  $title[generated!]
  $color[$getservervar[color]]
  $description[I generated a captcha code for you!]
$onlyif[$channelid==$getservervar[verificationchannel];]`
})