module.exports.command = ({
    name: "chatbot", 
  aliases: ["cb"],
code: `
$setServerVar[chatbot;off]

$color[$getServerVar[color]]
$description[Chatbot is now off, to turn it back on use \`$getservervar[prefix]cb on\` or \`$getservervar[prefix]cb on #channel mention\`]
$footer[Requested by $userTag[$authorID];$userAvatar[$authorID]]

$onlyPerms[managechannels;Only staff with manage channels permissions can use this]
$onlyIf[$checkContains[$message;off]==true;]`
});