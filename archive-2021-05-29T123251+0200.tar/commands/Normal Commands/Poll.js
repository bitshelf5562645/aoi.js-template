module.exports.command = ({
  name: "poll",
  code: `
$addReactions[<a:vote_no:765265576272461844>;<a:vote_yes:765265518658977854>]
$deletecommand
$title[Poll]
$description[$message?]
$footer[vote by reacting!]
$color[$getServerVar[color]]
$author[;$authorAvatar]
$cooldown[30s;Please wait %time% until using this command again!]
`
})