module.exports.command = ({
name: "tictactoe",
aliases: "ttt",
code: `$reactionCollector[$splitText[1];everyone;10m;1️⃣,2️⃣,3️⃣,4️⃣,5️⃣,6️⃣,7️⃣,8️⃣,9️⃣;place1,place2,place3,place4,place5,place6,place7,place8,place9;yes]
$textSplit[$sendMessage[{title:Tic Tac Toe!}{description:A round of Tic Tac Toe has started, good luck!

$getmessagevar[place1;$message[1]]|$getmessagevar[place2;$message[1]]|$getmessagevar[place3;$message[1]]
$getmessagevar[place4;$message[1]]|$getmessagevar[place5;$message[1]]|$getmessagevar[place6;$message[1]]
$getmessagevar[place7;$message[1]]|$getmessagevar[place8;$message[1]]|$getmessagevar[place9;$message[1]]}{color:$getservervar[color]};yes]]
$setuservar[sign;⭕;$mentioned[1;no]]
$setmessagevar[starter;$authorid]
$setmessagevar[player;$mentioned[1;no]]
$setmessagevar[whosturn;$mentioned[1;no]]

$onlyif[$userexists[$mentioned[1;no]]==true;You didn't mention a user, try again but mention a user!]
$argscheck[1;Please only mention a user to play with!]
`
});