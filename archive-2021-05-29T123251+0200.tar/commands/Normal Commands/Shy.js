module.exports.command = ({
  name: "shy",
  description: `Shy away from the mentioned user, this command sends an attachment of it.`,
  code: `$title[$username is shying away from $username[$finduser[$message]]!]
  $image[$jsonrequest[https://brapi.maruln.repl.co/api/timido;imagem]]
  $footer[requested by $usertag;$authoravatar]
  $addtimestamp
  $color[$getservervar[color]]
  $argscheck[1>;please mention someone or use their username!]`
})