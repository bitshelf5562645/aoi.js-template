module.exports.command = ({
  name: "captcha",
  code: `$title[Hold up!]
  $description[One small step until you can access this server!
Please send the exact same message you see in the image below! The captcha deletes in one minute!] $deletein[1m]
  $image[https://deuretin.sirv.com/0C0851C0-1EC6-4315-B8A6-94704C6F09EA.jpeg?text.0.text=$getUserVar[captcha]&text.0.position.y=-40%25]
  $color[$getservervar[color]]
  $awaitMessages[$authorID;1m;$getuservar[captcha];verify;]
$onlyif[$channelid==$getservervar[verificationchannel];]
  $onlyIf[$getuservar[captcha]!=$getvar[captcha];You haven't generated a captcha code yet!]`
});