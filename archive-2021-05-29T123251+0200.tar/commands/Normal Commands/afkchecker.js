module.exports.command = ({
name: "$alwaysExecute",
code: `$author[The user you mentioned is AFK!;$servericon]
$description[Hi there $usertag! $usertag[$mentioned[1;no]] is afk, please refrain from disturbing them!

**Reason:** \`\`\`$getuservar[afk_message;$mentioned[1;no]]\`\`\`]
$color[$getservervar[color]]
$onlyif[$getuservar[afk;$mentioned[1;no]]==true;]
$suppresserrors
`
})