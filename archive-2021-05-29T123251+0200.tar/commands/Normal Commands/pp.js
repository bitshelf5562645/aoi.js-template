module.exports.command = ({
  name: "pp",
  code: `$title[pp size calculator]

$description[$username[$mentioned[1;yes]]#$discriminator[$mentioned[1;yes]]’s pp

8$randomText[;=;==;===;====;=====;======;=======;========;=========;==========;===========;============;=============;==============;===============]D]
$footer[requested by $username[$authorID]#$discriminator[$authorID];$authorAvatar]
$color[$getservervar[color]]`
})