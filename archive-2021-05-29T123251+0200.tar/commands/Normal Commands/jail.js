module.exports.command = ({
  name: "jail",
  code: `$djseval[const Discord = require("discord.js");
const client = new Discord.Client()
const canvacord = require("canvacord")
        let img = message.mentions.members.size !== 0 ? message.mentions.users.first().displayAvatarURL({ format: "png" }) : message.attachments.size !== 0 ? message.attachments.first().url : message.author.displayAvatarURL({ format: "png" })
        canvacord.Canvas.jail(img, $replacetext[$replacetext[$nomentionmessage[1];yes;true;-1];no;false;-1]).then(image => {
        let attachment = new Discord.MessageAttachment(image, "locked_up.png")
        return message.channel.send(attachment)
})
  ]`
})