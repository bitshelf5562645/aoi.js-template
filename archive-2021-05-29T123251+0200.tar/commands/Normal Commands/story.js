module.exports.command = ({
  name: "story",
  description: `This command prints the storyline.`,
  code: `$color[f1c40f]
$title[$username[$authorID]#$discriminator[$authorID] requested the story]
$description[When leaving your parents’ house at the age of 20 you moved to a temporary hotel, while staying at that hotel you heard stories about a gigantic city which they called **BittyCity**, you were instantly interested and looked online if there were any places to stay and there were... thing is... there’s a different currency there, its called BittyCoins so you looked for a job there and found a simple job assembling car parts, it’s not the best but it’s enough to get you by.

**so to keep it short:**
You find yourself in a vast place named BittyCity, the streets look just perfect and so does everything else and you can’t help but wonder why you’re only just now discovering this gorgeous place.
$image[https://cdn.discordapp.com/attachments/776023361254981632/776026286232698910/7aaa26e308378fb802337138bb3bc05dimage0.jpg]]
$footer[requested by $username[$authorID]#$discriminator[$authorID];$authoravatar]
$addTimestamp`
})