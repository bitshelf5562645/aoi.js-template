module.exports.command = ({
  name: "kiss",
  description: `Hug the mentioned user, this command will send an attachment of it.`,
  code: `$title[$username kissed $username[$finduser[$message]]!]
  $image[$jsonrequest[https://brapi.maruln.repl.co/api/beijar;imagem]]
  $footer[requested by $usertag;$authoravatar]
  $color[$getservervar[color]]
  $addtimestamp
  $argscheck[1>;please mention someone or use their username!]`
})