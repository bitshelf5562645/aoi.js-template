module.exports.command = ({
  name: "clap",
  code: `$replaceText[$message; ; 👏 ;-1]
  $onlyIf[$checkContains[$message;@here;@everyone;@]==false;You can't mention anyone in the clap command to avoid raiders exploiting this command, sorry!]
 $argscheck[1>;Please say something!] `
  

  
})