module.exports.command = ({
name: "covid",
code: `$title[Covid in $message]
$description[$addfield[Country Population;$numberseparator[$jsonrequest[https://api.jastinch.xyz/coronavirus?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&country=$tolowercase[$message];population];,];no]
$addfield[Deaths;$numberseparator[$jsonrequest[https://api.jastinch.xyz/coronavirus?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&country=$tolowercase[$message];deaths];,];no
$addfield[Active Cases;$numberseparator[$jsonrequest[https://api.jastinch.xyz/coronavirus?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&country=$tolowercase[$message];active];,];yes]
$addfield[Confirmed Cases;$numberseparator[$jsonrequest[https://api.jastinch.xyz/coronavirus?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&country=$tolowercase[$message];confirmed];,];yes]]]
$thumbnail[$jsonrequest[https://api.jastinch.xyz/coronavirus?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&country=$tolowercase[$message];countryFlag]]
$color[$getservervar[color]]
$footer[Requested by $usertag;$authoravatar]
$addtimestamp
$suppresserrors[Country with the name $replacetext[$nomentionmessage;@;;-1] was not found!]
$argscheck[1>;Please select a country.]
`
})