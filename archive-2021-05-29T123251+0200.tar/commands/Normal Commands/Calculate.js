module.exports.command = ({
  name: "calculate",
  aliases: "calc",
  code: `$title[Calculate!]
  $description[Input:  \`\`\`$message\`\`\` Output: \`\`\`$math[$message]\`\`\`]
  $footer[requested by $usertag;$authoravatar]
  $color[$getservervar[color]]
  $addtimestamp
  $onlyIf[$checkcontains[$message;1;2;34;5;6;7;8;9;0]==true;Please tell me what to calculate!]`
})