module.exports.command = ({
name: "separate",
aliases: "sep",
code: `$replacetext[$replacetext[$replacetext[$message; ;** **;-1];; ;-1];* *   * *;**  **;-1] $deletecommand`
})