module.exports.command = ({
name: "hack",
code: `$description[Hacking $usertag[$finduser[$message]]...]
$color[$getservervar[color]]

$editIn[5s;{description:Discord token: $randomString[100]}{color:$getservervar[color]};{description:Email: $randomText[lordly123451234523@gmail.com;$username1234iamcool123@gmail.com;iainteverseentwoprettybestfriends@gmail.com;poopybutt$username@gmail.com;$usernamediesfromcoolness@gmail.com;verycoolrealgmail@gmail.com;discordbotsorg@gmail.com;walmartofficial123@gmail.com;asdfdrtertrt@gmail.com]}{color:$getservervar[color]};{description:Password: $randomText[whatthefuck;poop;gay;haha$username;ilovemoney;$username;iselldrugs;aefertewr;The bisector went through the binary.;cringegamer.xd;xX69$username420Xx]}{color:$getservervar[color]};{description:Last message sent: "$randomText[bro how do i tell her..;Love you step bro;I'm stuck in the dryer step bro;Sweet home alabama.;Frog you all.;tiktok sucks lol;i love watching weird things on weird websites haha;ok;I'm gay;Is 3 inches enough;Get free Vbucks at this website, wait lemme pull up the link shut up;She left me on read;what would happen if i got hacked lmao;bittyconomy is the best bot wtf lol;i love gacha;is 3 inches good or wat]"}{color:$getservervar[color]};{description:Location: $randomText[Canada;Earth;America;White house;Currently at home;Outside.]}{color:$getservervar[color]};{description:Hack complete}{color:$getservervar[color]};{description:All data has been deleted and is being sent to the internet.}{color:$getservervar[color]}]

$onlyIf[$mentioned[1;no]!=725463533814284419;{title:Oi!}{description:You're not allowed to hack my owner!}{color:$getservervar[color]}]
$onlyIf[$finduser[$message]!=$clientid;{title:Oi!}{description:You're not allowed to hack me!}{color:$getservervar[color]}]
$onlyIf[$finduser[$message]!=$authorid;{title:Oi!}{description:You're not allowed to hack yourself!}{color:$getservervar[color]}]
`
})