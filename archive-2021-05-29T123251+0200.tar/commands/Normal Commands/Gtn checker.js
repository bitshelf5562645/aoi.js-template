module.exports.command = ({
name: "$alwaysExecute",
code: `$title[Congrats!]
$description[Congrats, you guessed the right number! The number was $message[1]! You have won 350K BittyCoins $customemoji[bittycoin]! Guess the number has now ended, for a new round to start please ask one of the server staff to start a new round! Good luck!]
$color[$getservervar[color]]
$footer[Guess the number in $servername;$servericon]
$setservervar[winning_number;Doesn't exist.]
$setglobaluservar[money;$sum[$getglobaluservar[money];350000]]
$onlyif[$message[1]==$getservervar[winning_number];{title:Nope}{description:Too bad, that is not the winning number, try again!}{color:RED}{footer:Guess the number in $servername:$servericon}]
$onlyif[$getservervar[winning_number]!=Doesn't exist.;Someone has already guessed the number, please wait until a staff member starts a new round!]
$onlyif[$channelid==$getservervar[guess_the_number_channel];]
$onlyif[$checkcontains[$message;1;2;3;4;5;6;7;8;9;0]==true;]
$onlyif[$checkcontains[$message;gtn;guessthenumber]==false;]
`
})