module.exports.command = ({
 name: "meme",
 code: `$color[$getServerVar[color]]
 $description[$jsonRequest[https://meme-api.herokuapp.com/gimme;title]]
$image[$jsonRequest[https://meme-api.herokuapp.com/gimme;url]]
$author[$jsonRequest[https://meme-api.herokuapp.com/gimme;ups] upvotes!] 
$title[**Direct link to meme!**;$jsonRequest[https://meme-api.herokuapp.com/gimme;postLink]] $footer[posted on r/$jsonRequest[https://meme-api.herokuapp.com/gimme;subreddit]]`
});