module.exports.command = ({
name: "8ball",
code: `$title[8 Ball]
$description[$addfield[Output;$randomtext[It is certain.; It is decidedly so.;Without a doubt.;Yes – definitely.;You may rely on it;As I see it, yes.;Most likely.;Outlook good.;Yes.;Signs point to yes.;Better not tell you now.;Cannot predict now.;Please try again.;Don't count on it.;My reply is no.;My sources say no.;Outlook not so good;Very doubtful.];no]
$addfield[Input;$message;no]]
$color[$getservervar[color]]
$argscheck[1>;Missing question.]
`
})