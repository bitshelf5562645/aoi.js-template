module.exports.command = ({
name: "faq",
code: `$title[FAQ number $message]
$description[\`$getvar[faq_$message]\`]
$color[$getservervar[color]]
$footer[requested by $usertag;$authoravatar]
$addtimestamp
$argscheck[1;{title:FAQ list}{description:FAQ 1: Where can I vote?

FAQ 2: Are vote based rewards ever coming back?

FAQ 3: Can I help work on the bot?

FAQ 4: How long does it normally take for a bug to get fixed?

FAQ 5: I found a bug, what do I do?

FAQ 6: Can I help with command ideas?

FAQ 7: Is there any special command I have to run to start using economy?

FAQ 8: Bittyconomy reminds me of other economy bots, why is this?

FAQ 9: I've seen TOBC in a few commands, what does this mean?

FAQ 10: How much money would one Bittycoin be worth if it was real?}{color:$getservervar[color]}]
$suppresserrors[{title:Wrong input}{description:Wrong input provided, please only provide the number of the FAQ you want to see.}{color:$getservervar[color]}]
`
})