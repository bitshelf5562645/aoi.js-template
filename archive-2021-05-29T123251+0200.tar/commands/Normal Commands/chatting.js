module.exports.command = ({
    name: "$alwaysExecute", 
code: `
$reply[$messageid;$replacetext[$replacetext[$replacetext[$jsonrequest[https://api.jastinch.xyz/chatbot?key=jc_api.TsI1KfMDDSbI26V5aVu8LNyQ9&message=$replacetext[$nomentionmessage; ;%20;-1];response];api.affiliateplus.xyz;BittyCity;-1];Lebyy_Dev;$usertag[$botownerid];-1];@;;-1];no]
$onlyIf[$checkContains[$message;B!]==false;]
$onlyIf[$channelID==$getServerVar[chatChannel];]
$onlyIf[$getServerVar[chatbot]!=off;]
`});