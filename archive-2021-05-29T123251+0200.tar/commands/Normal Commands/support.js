module.exports.command = ({
name: "support",
description: `This command sends a hyperlink to my support server.`,
code: `
$title[Bittyconomy support]
$description[To join the support server for this bot click [**here**](https://discord.gg/VXvWbZmzhG)]
$color[$getServerVar[color]]
$image[https://cdn.discordapp.com/attachments/790209471204556800/810120257770881034/image0.gif]
$thumbnail[https://cdn.discordapp.com/attachments/791432550451118120/792449595526348850/image0.gif]`

})