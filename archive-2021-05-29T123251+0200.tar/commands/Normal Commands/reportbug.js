module.exports.command = ({
  name: "reportbug",
  code: `$color[f1c40f]
$title[$username[$authorID]#$discriminator[$authorID] - <@$authorID> reported a bug!]
<@&775828181877391361>
$description[\`\`\`$message\`\`\`

If $usertag[725463533814284419] reacted with ✔️ then the bug is fixed]
$deletecommand
$footer[requested by $usertag;$authoravatar]
$addTimestamp
$usechannel[776784907875516427]
$globalCooldown[10m;You need to wait %time% to use this again!]`
})