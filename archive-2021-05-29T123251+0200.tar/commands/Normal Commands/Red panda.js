module.exports.command = ({
  name: "redpanda",
  description: `This command sends a random picture of a red panda.`,
  aliases: ["rp"],
  code: `$title[Look at this lil' guy]
  $description[lil' red panda!]
  $image[$jsonrequest[https://some-random-api.ml/img/red_panda;link;An error occurred, please try again later!]]
  $footer[requested by $usertag[$authorid];$authoravatar]
  $addtimestamp
  $color[$getservervar[color]]
    `
})