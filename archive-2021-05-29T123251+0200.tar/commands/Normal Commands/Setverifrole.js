module.exports.command = ({
name: "setverifiedrole",
aliases: ["setverifrole","svr"],
code: `$setServerVar[verified;$findrole[verified]]
$title[verified role!]
$color[$getservervar[color]]
$description[I have now set the verified to the role <@&$findrole[verified]>!]
$setservervar[verificationchannel;$channelid]
$onlyIf[$roleexists[$findrole[verified]]==true;Please send an existing role!]
$suppresserrors[An error occurred, it seems a verified role doesn't exist, please create a role and call it \`verified\` and try again!]$onlyperms[manageserver;Only users with manage server permissions can use this.]
`
})