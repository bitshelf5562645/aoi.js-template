module.exports.command = ({
  name: "ship",
  code: `$title[shipping!]
  $description[Ship complete! $random[1;100]%!]
  $image[https://api.cool-img-api.ml/ship?user=$replaceText[$replaceText[$replaceText[$authoravatar&user2=$useravatar[$finduser[$message]];webp;png;-1];jpg;png;-1];gif;png;-1]]
$argscheck[1;Please mention someone!]
$onlyIf[$mentioned[1;yes]!=;Please mention someone!]
$color[$getservervar[color]]`
})