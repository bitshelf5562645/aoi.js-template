module.exports.command = ({
  name: "setlogschannel",
  aliases: ["slc"],
  code: `$color[$getservervar[color]]
  $title[Logs]
  $description[I will now log deleted and edited messages, role updates channel updates, etc in <#$mentionedchannels[1;yes]>]
  $setservervar[logschannel;$mentionedchannels[1;yes]]
  $onlyperms[managechannels;Only staff with manage channel permissions can use this!]
  $onlyif[$channelexists[$mentionedchannels[1;yes]]==true;]`
})