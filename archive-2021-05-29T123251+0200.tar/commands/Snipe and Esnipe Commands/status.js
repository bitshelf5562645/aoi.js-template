module.exports.status = ({
    text: "$servercount Servers || $numberseparator[$allmemberscount;,] Users",
    status: "WATCHING",
    time: 10
}); //To use multiple, create more status.js files 