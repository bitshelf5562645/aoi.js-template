module.exports.status = ({
    text: "B!help || $numberseparator[$allmemberscount;,] users",
    status: "WATCHING",
    time: 10
})