module.exports.updateCommand = ({
	channel: `$getServerVar[logschannel]`,
  code: `$author[$usertag[$authorid];$authoravatar]
  $color[$getServerVar[color]]
  $title[message edited!]
  $description[Someone edited a message!
  $addField[After:;\`\`\`$message\`\`\`;no]
  $addField[Before:;\`\`\`$oldmessage\`\`\`;no]
  $addField[by user:;<@$authorID>;yes]
  $addField[channel:;<#$channelused>;yes]]
  $suppressErrors
$footer[;$servericon]
$addtimestamp
  
 $onlyif[$message!=$oldmessage;]
  $onlyIf[$channelExists[$getServerVar[logschannel]]==true;]
$onlyif[$hasperms[$authorid;managemessages]==false;]
$suppresserrors`
});