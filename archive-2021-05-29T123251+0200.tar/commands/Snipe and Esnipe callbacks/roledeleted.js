module.exports.roleDeleteCommand = ({
channel: "$getservervar[logschannel]",
code: `$color[$getServerVar[color]]
  $title[Role Deleted!]
  $description[Role deleted!
  $addField[Name:;\`\`\`$oldrole[name]\`\`\`;yes]]
$footer[;$servericon]
$addtimestamp
  $onlyIf[$channelExists[$getServerVar[logschannel]]==true;]
  $suppresserrors`
});