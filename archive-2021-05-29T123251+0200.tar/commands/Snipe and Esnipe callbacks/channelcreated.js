module.exports.channelCreateCommand = ({
channel: "$getservervar[logschannel]",
code: `$color[$getServerVar[color]]
  $title[channel created!]
  $description[New channel created!
  $addField[Name:;<#$newchannel[id]>;yes]]
$footer[;$servericon]
$addtimestamp
  $onlyIf[$channelExists[$getServerVar[logschannel]]==true;]
 $suppresserrors `
});