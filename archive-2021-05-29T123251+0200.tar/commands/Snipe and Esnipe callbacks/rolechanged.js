module.exports.roleUpdateCommand = ({
channel: "$getservervar[logschannel]",
code: `$color[$getServerVar[color]]
  $title[Role name changed!]
  $description[Role name updated!
  $addField[Mention:;<@&$newrole[id]>;yes]
  $addField[Old name:;\`\`\`$oldrole[name]\`\`\`;yes]
  $addField[New name:;\`\`\`$newrole[name]\`\`\`;yes]]
$footer[;$servericon]
$addtimestamp
$onlyif[$newrole[name]!=$oldrole[name];]
  $onlyIf[$channelExists[$getServerVar[logschannel]]==true;]
  $suppresserrors`
});