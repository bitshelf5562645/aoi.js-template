module.exports.roleCreateCommand = ({
channel: "$getservervar[logschannel]",
code: `$color[$getServerVar[color]]
  $title[Role created!]
  $description[New role created!
  $addField[Mention:;<@&$newrole[id]>;yes]
  $addField[Name:;\`\`\`$newrole[name]\`\`\`;yes]
  $addField[Hoisting?:;$newrole[hoist];yes]]
$footer[;$servericon]
$addtimestamp
  $onlyIf[$channelExists[$getServerVar[logschannel]]==true;]
  $suppresserrors`
});