module.exports.deletedCommand = ({
	channel: `$getServerVar[logschannel]`,
	code: `$author[$usertag[$authorid];$authoravatar]
  $color[$getServerVar[color]]
  $title[message deleted!]
  $description[Someone deleted a message!
  $addField[Content:;\`\`\`$message\`\`\`;yes]
  $addField[by user:;<@$authorID>;yes]
  $addField[channel:;<#$channelused>;yes]]
  $suppressErrors$footer[;$servericon]
$addtimestamp
  $onlyIf[$channelExists[$getServerVar[logschannel]]==true;]
$onlyif[$hasperms[$authorid;managemessages]==false;]
  $suppresserrors`
});
