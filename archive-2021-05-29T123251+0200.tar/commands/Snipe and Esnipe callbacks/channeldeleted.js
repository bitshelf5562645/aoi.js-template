module.exports.channelDeleteCommand = ({
channel: "$getservervar[logschannel]",
code: `$color[$getServerVar[color]]
  $title[Channel Deleted!]
  $description[A Channel Was Deleted!
  $addField[Name:;$oldchannel[name];yes]]
$footer[$servername;$servericon]
$addtimestamp
  $onlyIf[$channelExists[$getServerVar[logschannel]]==true;]
 $suppresserrors `
});